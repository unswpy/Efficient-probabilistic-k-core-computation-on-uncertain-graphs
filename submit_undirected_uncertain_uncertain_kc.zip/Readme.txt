All parameters are set in main function. Threshold, epsilon and delta are the same as meaning in our paper.
The value of task is set as following:
task 1 computes difference between new model and kdd model
task 2 computes difference between expected result of new model and weighted model
task 3 computes time and difference between naive and new model
task 4 computes original, certainDecomposition and upperbound candidate size
task 5 computes time and difference between naive and using result candidate as sample candidate
task 6 computes time of original, only core value order, upper bound markov and early terminate method
task 7 computes time of naive method upper boundand double early terminate algorithm
task 8 computes time of naive method(without core decomposition), early terminate and speed-up-3
task 9 computes time of naive method(without core decomposition), speed-up-2 and speed-up-3

Output files' name are like: 
task9_flickr_0.100000_0.100000_0.700000
which means the result of task9_dataset_epsilon_delta_threshold(or k).