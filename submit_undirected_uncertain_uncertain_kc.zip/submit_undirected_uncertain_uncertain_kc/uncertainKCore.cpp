#include "uncertainKCore.h"
int NODE_COUNT = -1;
int EDGE_COUNT = -1;
////////// experiment functions
char* getOutFileName(string& tempS, char* dataset, int k, double epsilon, double delta, double threshold, int task, char changeKOrThreshold)
{
	string temp(dataset);
	if (changeKOrThreshold == 'k')
	{
		//tempS = "task" + to_string(task) + "/"+"task" + to_string(task) + "_" + temp + "_" + to_string(epsilon) + "_" + to_string(delta) + "_" + to_string(threshold);
		tempS = "task" + to_string(task) + "_" + temp + "_" + to_string(epsilon) + "_" + to_string(delta) + "_" + to_string(threshold);
	}
	else if (changeKOrThreshold == 't')
	{
		tempS = "task" + to_string(task) + "_" + temp + "_" + to_string(epsilon) + "_" + to_string(delta) + "_" + to_string(k);
		//tempS = "task" + to_string(task) + "/" + "task" + to_string(task) + "_" + temp + "_" + to_string(epsilon) + "_" + to_string(delta) +"_" + to_string(k);
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
		return "";
	}
	return const_cast<char*>(tempS.c_str());
}

void chooseTask(char* dataset, int k, double epsilon, double delta, double threshold, int task, char changeKOrThreshold)
{
	string tempS;
	if (!configureDataset(dataset))
	{
		cout << "configure dataset error" << endl;
		//system("pause");
		return;
	}

	char *fileName = getOutFileName(tempS, dataset, k, epsilon, delta, threshold, task, changeKOrThreshold);
	ofstream outFile(fileName, ios::app);
	switch (task)
	{
	case 1:
		task1(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 2:
		task2(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 3:
		task3(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 4:
		task4(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 5:
		task5(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 6:
		task6(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 7:
		task7(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 8:
		task8(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 9:
		task9(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	case 10:
		task8(dataset, k, epsilon, delta, threshold, outFile, changeKOrThreshold);
		break;
	default:
		break;
	}
	outFile.close();
}

bool configureDataset(char* dataset)
{
	if (strcmp(dataset, "dblp") == 0)
	{
		NODE_COUNT = 684920;
		EDGE_COUNT = 2284995;
	}
	else if (strcmp(dataset, "flickr") == 0)
	{
		NODE_COUNT = 241000;
		EDGE_COUNT = 301000;
	}
	else if (strcmp(dataset, "biomine") == 0)
	{
		NODE_COUNT = 1008201;
		EDGE_COUNT = 18008202;
	}
	else if (strcmp(dataset, "amazonrandp") == 0)
	{
		NODE_COUNT = 548552;
		EDGE_COUNT = 925873;
	}
	else if (strcmp(dataset, "livejournalrandp") == 0)
	{
		NODE_COUNT = 3997963;
		EDGE_COUNT = 34681190;
	}
	else if (strcmp(dataset, "facebookrandp") == 0 || strcmp(dataset, "facebookrandp0.5") == 0)
	{
		NODE_COUNT = 4100;
		EDGE_COUNT = 88235;
	}
	else if (strcmp(dataset, "email_eronrandp") == 0 || strcmp(dataset, "email_eronrandp0.5") == 0)
	{
		NODE_COUNT = 36699;
		EDGE_COUNT = 183832;
	}
	else if (strcmp(dataset, "yelprandp") == 0 || strcmp(dataset, "yelprandp0.5") == 0)
	{
		NODE_COUNT = 552340;
		EDGE_COUNT = 1781910;
	}
	else
	{
		cout << "only dblp flickr and xxx can be used" << endl;
		return false;
	}
	return true;
}


void task1(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	cout << "kddCoreUpdate" << endl;
	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	cout << "certain core decomposition end" << endl;
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	start = clock();
	dur = (double)(start - preStart);
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		kddNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x >= 0 && edges[i].y >= 0)
		{
			kddNode[edges[i].x] = 1;
			kddNode[edges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		if (kddNode[i] == 1)
		{
			afternum++;
		}
	}
	initArray(kddNode, NODE_COUNT + 1);

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	end = clock();
	dur = (double)(end - start);
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	//markov inequality to reduce candidate

	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequality(newEdgeNum, weighedEdges, maxDegree, threshold, nodeNum, k, candidateDegrees);

	markovEnd = clock();
	dur = (double)(markovEnd - end);
	printf("markov inequality used time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "markov candidate" << noden << endl;
	newModelDecompositionEarlyStopWithoutEdgeOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	addNewModelNodes(newModelNodeEarly, threshold, sampleResult, nodeNum);

	cout << "new model end" << endl;

	end2 = clock();
	dur = (double)(end2 - end);
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModel" << endl;
	double result = checkResult(newModelNodeEarly, kddUpdatedNode, nodeNum);


	cout << "threshold" << threshold << "k || " << k << " result|| " << result << endl;
	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << result << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << result << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}
	double temp = 0;

	//system("pause");;
	//int no_components = 0;




	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}
void task2(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)
{
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;
	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	start = clock();
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int afternum = 0;

	initArray(kddNode, NODE_COUNT + 1);

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	end = clock();
	dur = (double)(end - start);
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	//markov inequality to reduce candidate

	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequality(newEdgeNum, weighedEdges, maxDegree, threshold, nodeNum, k, candidateDegrees);

	markovEnd = clock();
	dur = (double)(markovEnd - end);
	printf("markov inequality used time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "markov candidate" << noden << endl;
	newModelDecompositionEarlyStopWithoutEdgeOrderExpectedValue(edges, nodeNum, edgeNum, maxDegree, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);

	cout << "new model end" << endl;

	end2 = clock();
	dur = (double)(end2 - end);
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModel" << endl;

	for (k = 2; k <= 40; k++)
	{

		newEdgeNum = kddUpdatedEdgeNum;
		for (int i = 0; i < kddUpdatedEdgeNum; i++)
		{
			weighedEdges[i].x = kddUpdatedEdges[i].x;
			weighedEdges[i].y = kddUpdatedEdges[i].y;
			weighedEdges[i].p = kddUpdatedEdges[i].p;
		}


		weighedCoreDecomposition(newEdgeNum, weighedEdges, threshold, nodeNum, k, degrees);
		initArray(weighedNode, nodeNum + 1);
		initArray(newModelNodeEarly, nodeNum + 1);
		addKddNodes(weighedEdges, nodeNum, newEdgeNum, weighedNode);
		addNewModelNodes(newModelNodeEarly, k, sampleResult, nodeNum);
		//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);


		double result = checkResult(newModelNodeEarly, weighedNode, nodeNum);


		cout << "threshold" << threshold << "k || " << k << " result|| " << result << endl;
		outFile << k << '\t' << result << endl;


	}
	double temp = 0;

	//system("pause");
	//delete[] kddNode;
	delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}

void task3(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	double certainDecompositionTime = 0;
	double naiveTime = 0;
	double newModelTime = 0;
	double markovTime = 0;
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	//kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	//addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	//cout << "kddCoreUpdate" << endl;
	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	cout << "certain core decomposition end" << endl;
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	start = clock();
	dur = (double)(start - preStart);
	certainDecompositionTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		kddNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x >= 0 && edges[i].y >= 0)
		{
			kddNode[edges[i].x] = 1;
			kddNode[edges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		if (kddNode[i] == 1)
		{
			afternum++;
		}
	}
	initArray(kddNode, NODE_COUNT + 1);

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	newModelDecompositionChainNoOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon);
	addNewModelNodes(newModelNode, threshold, sampleResult, nodeNum);

	cout << "new model no order end" << endl;
	end = clock();
	dur = (double)(end - start);
	naiveTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	//markov inequality to reduce candidate

	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequality(newEdgeNum, weighedEdges, maxDegree, threshold, nodeNum, k, candidateDegrees);

	markovEnd = clock();
	dur = (double)(markovEnd - end);
	markovTime = dur;
	printf("markov inequality used time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "markov candidate" << noden << endl;
	newModelDecompositionEarlyStopWithoutEdgeOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	addNewModelNodes(newModelNodeEarly, threshold, sampleResult, nodeNum);

	cout << "new model end" << endl;

	end2 = clock();
	dur = (double)(end2 - end);
	newModelTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModel" << endl;
	double result = checkResult(newModelNodeEarly, newModelNode, nodeNum);


	cout << "threshold" << threshold << "k || " << k << " result|| " << result << endl;
	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}
	double temp = 0;

	//system("pause");;
	//int no_components = 0;




	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}
void task4(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	int originalCandidateSize = 0;
	int certainDecompositionCandiditeSize = 0;
	int upperboudCandidateSize = 0;
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	cout << "maxDegree" << maxDegree << endl;
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	//kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	//addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	//cout << "kddCoreUpdate" << endl;
	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	originalCandidateSize = caclTotalNodeNum(edgeNum, nodeNum, edges);
	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	certainDecompositionCandiditeSize = caclTotalNodeNum(edgeNum, nodeNum, edges);
	cout << "certain core decomposition end" << endl;
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	start = clock();
	dur = (double)(start - preStart);
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	int afternum = 0;


	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	//markov inequality to reduce candidate

	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequality(newEdgeNum, weighedEdges, maxDegree, threshold, nodeNum, k, candidateDegrees);
	upperboudCandidateSize = noden;


	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << originalCandidateSize << '\t' << certainDecompositionCandiditeSize << '\t' << upperboudCandidateSize << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << originalCandidateSize << '\t' << certainDecompositionCandiditeSize << '\t' << upperboudCandidateSize << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}

	//system("pause");;
	//int no_components = 0;




	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}
void task5(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	double certainDecompositionTime = 0;
	double naiveTime = 0;
	double newModelTime = 0;
	double markovTime = 0;
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	//kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	//addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	//cout << "kddCoreUpdate" << endl;
	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	cout << "certain core decomposition end" << endl;
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	start = clock();
	dur = (double)(start - preStart);
	certainDecompositionTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		kddNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x >= 0 && edges[i].y >= 0)
		{
			kddNode[edges[i].x] = 1;
			kddNode[edges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		if (kddNode[i] == 1)
		{
			afternum++;
		}
	}
	initArray(kddNode, NODE_COUNT + 1);

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	newModelDecompositionChainNoOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon);
	addNewModelNodes(newModelNode, threshold, sampleResult, nodeNum);

	cout << "new model no order end" << endl;
	end = clock();
	dur = (double)(end - start);
	naiveTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	//markov inequality to reduce candidate

	//int noden = kddCoreDecompositionOriginSpeedUpMarkovInequality(newEdgeNum, weighedEdges, maxDegree, threshold, nodeNum, k, candidateDegrees);
	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequalityRemoveEdges(edgeNum, edges, maxDegree, threshold, nodeNum, k, candidateDegrees);

	markovEnd = clock();
	dur = (double)(markovEnd - end);
	markovTime = dur;
	printf("markov inequality used time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "markov candidate" << noden << endl;
	newModelDecompositionEarlyStopWithoutEdgeOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	addNewModelNodes(newModelNodeEarly, threshold, sampleResult, nodeNum);

	cout << "new model end" << endl;

	end2 = clock();
	dur = (double)(end2 - end);
	newModelTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModel" << endl;
	double result = checkResult(newModelNodeEarly, newModelNode, nodeNum);


	cout << "threshold" << threshold << "k || " << k << " result|| " << result << endl;
	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}
	double temp = 0;

	//system("pause");;
	//int no_components = 0;




	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}
void task6(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	double coreValueTime = 0;
	double upperBoundTime = 0;
	double earlyTerminateTime = 0;
	double certainDecompositionTime = 0;
	double naiveTime = 0;
	double newModelTime = 0;
	double markovTime = 0;
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	//kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	//addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	//cout << "kddCoreUpdate" << endl;
	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	cout << "certain core decomposition end" << endl;
	start = clock();
	dur = (double)(start - preStart);
	certainDecompositionTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));

	//certain decomposition done

	//naive method starts
	//init new weighedEdges and newEdgeNum
	start = clock();
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	newModelDecompositionChainNoOrder(weighedEdges, nodeNum, newEdgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon);
	cout << "new model original method end" << endl;
	end = clock();
	dur = (double)(end - start);
	naiveTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	//naive method ends


	//upper bound and markov inequality starts
	//init new weighedEdges and newEdgeNum
	start = clock();
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequality(newEdgeNum, weighedEdges, maxDegree, threshold, nodeNum, k, candidateDegrees);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	newModelDecompositionChainNoOrderClacNoden(weighedEdges, nodeNum, newEdgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);

	end = clock();
	dur = (double)(end - start);
	upperBoundTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "upper bound end" << endl;
	// upper bound and markov inequality ends

	//without core value order early terminate method starts
	start = clock();
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	noden = caclTotalNodeNum(edgeNum, nodeNum, edges);
	newModelDecompositionEarlyStopWithoutEdgeOrderWithoutCoreValue(weighedEdges, nodeNum, newEdgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	end = clock();
	dur = (double)(end - start);
	coreValueTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "core value order end" << endl;
	//core value order mehtod ends


	//early terminate method starts
	start = clock();
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	noden = caclTotalNodeNum(newEdgeNum, nodeNum, weighedEdges);
	newModelDecompositionEarlyStopWithoutEdgeOrder(weighedEdges, nodeNum, newEdgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	end = clock();
	dur = (double)(end - start);
	earlyTerminateTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "earlyTerminateTime end" << endl;
	//early terminate method ends

	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + coreValueTime) << '\t'
			<< (certainDecompositionTime + upperBoundTime) << '\t' << (certainDecompositionTime + earlyTerminateTime) << '\t' << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + coreValueTime) << '\t'
			<< (certainDecompositionTime + upperBoundTime) << '\t' << (certainDecompositionTime + earlyTerminateTime) << '\t' << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}

	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}

void task7(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	double certainDecompositionTime = 0;
	double naiveTime = 0;
	double newModelTime = 0;
	double markovTime = 0;
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	//kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	//addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	//cout << "kddCoreUpdate" << endl;



	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	//update nodeState
	cout << nodeNum << " nodes" << endl;
	int* nodeState = new int[nodeNum + 1];
	initArrayWithValue<int>(nodeState, nodeNum + 1, PRUNED);
	for (int i = 0; i < edgeNum; i++)
	{
		nodeState[edges[i].x] = TOCONFIRM;
		nodeState[edges[i].y] = TOCONFIRM;
	}
	//
	cout << "certain core decomposition end" << endl;
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	start = clock();
	dur = (double)(start - preStart);
	certainDecompositionTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		kddNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x >= 0 && edges[i].y >= 0)
		{
			kddNode[edges[i].x] = 1;
			kddNode[edges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		if (kddNode[i] == 1)
		{
			afternum++;
		}
	}
	initArray(kddNode, NODE_COUNT + 1);

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	newModelDecompositionChainNoOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon);
	addNewModelNodes(newModelNode, threshold, sampleResult, nodeNum);

	cout << "new model no order end" << endl;


	// new a orderEdge to be pruned in upper bound and use in approximate algorithm without GT
	orderEdge* oEdge = new orderEdge[edgeNum + 1];
	for (int i = 0; i < edgeNum; i++)
	{
		oEdge[i].x = edges[i].x;
		oEdge[i].y = edges[i].y;
		oEdge[i].p = edges[i].p;
		oEdge[i].edgeIndex = i;
	}
	end = clock();
	//end of init orderEdge oEdge

	dur = (double)(end - start);
	naiveTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	//markov inequality to reduce candidate

	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequalityWithNodeStateRemoveEdges(newEdgeNum, oEdge, maxDegree, threshold, nodeNum, k, candidateDegrees, nodeState);
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << sampleSize << " samples in total" << endl;
	cout << newEdgeNum << "new edges" << endl;
	//////
	//init all the varible needed in  our doule early terminate program according to noden
	int sizeToConfrimNodes = 0;//store the num of nodes remaining to be confirm
	int* curNodeState = new int[nodeNum + 1];
	copyArray<int>(nodeState, curNodeState, nodeNum + 1);
	queue<unsigned> nodeQueue;//store active nodes
	short* allEdgeState = new short[(edgeNum + 1)*(sampleSize + 1)]; //allEdgeState[i*(edgenum+1)+j] means sample i , edge j
	initArrayWithValue<short>(allEdgeState, (edgeNum + 1)*(sampleSize + 1), -1);
	int* allNodeState = new int[(nodeNum + 1)*(sampleSize + 1)]; //allNodeState[i*(nodeNum+1)+j] means sample i , node j

	upLowNum* nodeUL = new upLowNum[(sampleSize + 1)*(nodeNum + 1)]; // nodeUL[i*(nodeNum+1)+j] means sample i , node j

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i < sampleSize; i++)
	{
		for (int j = 0; j <= nodeNum; j++)
		{
			nodeUL[i*(nodeNum + 1) + j].remainingEdges = degrees[j];
			nodeUL[i*(nodeNum + 1) + j].curEdges = 0;
			nodeUL[i*(nodeNum + 1) + j].solidEdges = 0;
		}
	}
	//initArrayWithValue<int>(allNodeState, (nodeNum + 1)*(sampleSize + 1),TOCONFIRM);

	for (int i = 0; i < sampleSize; i++)
	{
		for (int j = 0; j <= nodeNum; j++)
		{
			if (nodeState[j] != PRUNED)
			{
				allNodeState[i*(nodeNum + 1) + j] = TOCONFIRM;
			}
			else
			{
				allNodeState[i*(nodeNum + 1) + j] = nodeState[j];
			}
		}
	}

	//nodeState to find candidate nodes 1 means in result, 0 means not in, -1 means to be confirm
	/////


	/*int minusNum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
	if (nodeState[i] == -1)
	{
	minusNum++;
	}
	}
	cout << minusNum << "nodes to be " << endl;*/
	markovEnd = clock();
	dur = (double)(markovEnd - end);
	markovTime = dur / CLOCKS_PER_SEC;
	printf("markov inequality used time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "markov candidate" << noden << endl;
	cout << edgeNum << "before node state" << endl;
	for (int i = 0; i <= nodeNum; i++)
	{
		sampleResult[i] = 0;
	}

	clock_t uStart, uEnd;
	uStart = clock();

	newModelDecompositionChainNoOrderClacNoden(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	uEnd = clock();

	double upTime = double(uEnd - uStart) / CLOCKS_PER_SEC;
	printf("up Use Time:%f\n", upTime);

	clock_t tempS, tempE;
	tempS = clock();

	newModelDecompositionEarlyStopWithoutEdgeOrderWithNodeState(oEdge, nodeNum, newEdgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden, nodeState, allEdgeState, allNodeState, nodeUL, edgeNum);
	cout << nodeNum << " nodes" << endl;

	tempE = clock();
	dur = (double)(tempE - tempS);
	printf("al Use Time:%f\n", (dur / CLOCKS_PER_SEC));

	//update node state
	for (int i = 0; i <= nodeNum; i++)
	{
		if (sampleResult[i] >= threshold)
		{
			nodeState[i] = CONFIRMED;
		}
	}
	//
	// to finish our doule early terminate algorithms
	// init oEdge to original edges
	for (int i = 0; i < edgeNum; i++)
	{
		oEdge[i].x = edges[i].x;
		oEdge[i].y = edges[i].y;
		oEdge[i].p = edges[i].p;
		oEdge[i].edgeIndex = i;
	}
	//
	newModelDecompositionEarlyStopWithoutEdgeOrderStateTransfer(oEdge, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden, nodeState, allEdgeState, allNodeState, nodeUL, threshold, newModelNodeEarly);







	//addNewModelNodes(newModelNodeEarly, threshold, sampleResult, nodeNum);

	cout << "new model end" << endl;

	end2 = clock();
	dur = (double)(end2 - tempS);
	newModelTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModel" << endl;
	double result = checkResult(newModelNodeEarly, newModelNode, nodeNum);


	cout << "threshold" << threshold << "k || " << k << " result|| " << result << endl;

	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (upTime + certainDecompositionTime + markovTime) << '\t' << (markovTime + certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (upTime + certainDecompositionTime + markovTime) << '\t' << (markovTime + certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}
	double temp = 0;

	//system("pause");;
	//int no_components = 0;




	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}

void task8(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	double certainDecompositionTime = 0;
	double naiveTime = 0;
	double newModelTime = 0;
	double markovTime = 0;
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	//kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	//addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	//cout << "kddCoreUpdate" << endl;
	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	start = clock();
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	newModelDecompositionChainNoOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon);
	addNewModelNodes(newModelNode, threshold, sampleResult, nodeNum);

	cout << "new model no order end" << endl;
	end = clock();
	dur = (double)(end - start);
	naiveTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));



	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	cout << "certain core decomposition end" << endl;
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	start = clock();
	dur = (double)(start - preStart);
	certainDecompositionTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		kddNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x >= 0 && edges[i].y >= 0)
		{
			kddNode[edges[i].x] = 1;
			kddNode[edges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		if (kddNode[i] == 1)
		{
			afternum++;
		}
	}
	initArray(kddNode, NODE_COUNT + 1);


	//markov inequality to reduce candidate
	end = clock();
	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequality(newEdgeNum, weighedEdges, maxDegree, threshold, nodeNum, k, candidateDegrees);

	markovEnd = clock();
	dur = (double)(markovEnd - end);
	markovTime = dur;
	printf("markov inequality used time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "markov candidate" << noden << endl;
	newModelDecompositionEarlyStopWithoutEdgeOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	addNewModelNodes(newModelNodeEarly, threshold, sampleResult, nodeNum);

	cout << "new model end" << endl;

	end2 = clock();
	dur = (double)(end2 - end);
	newModelTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModel" << endl;


	//withoutGT
	start = clock();
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	noden = kddCoreDecompositionOriginSpeedUpMarkovInequalityRemoveEdges(edgeNum, edges, maxDegree, threshold, nodeNum, k, degrees);
	//kddnode
	newModelDecompositionEarlyStopWithoutEdgeOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden);
	addNewModelNodes(kddNode, threshold, sampleResult, nodeNum);
	end = clock();
	dur = (double)(end - start);
	double withoutGT = dur / CLOCKS_PER_SEC;
	//newModelTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModelWithoutGT" << endl;
	//end of without GT


	double result = checkResult(newModelNodeEarly, newModelNode, nodeNum);
	double result2 = checkResult(newModelNodeEarly, kddNode, nodeNum);

	cout << "threshold" << threshold << "k || " << k << " result|| " << result << endl;
	cout << "threshold" << threshold << "k || " << k << " result|| " << result2 << endl;
	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + newModelTime) << '\t' << (certainDecompositionTime + withoutGT) << '\t' << result << '\t' << result2 << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << (naiveTime + certainDecompositionTime) << '\t' << (certainDecompositionTime + newModelTime) << '\t' << (certainDecompositionTime + withoutGT) << '\t' << result << '\t' << result2 << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}
	double temp = 0;

	//system("pause");;
	//int no_components = 0;




	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}
void task9(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold)//compute difference kdd and our modle
{
	double certainDecompositionTime = 0;
	double naiveTime = 0;
	double newModelTime = 0;
	double markovTime = 0;
	cout << "k = " << k << endl;
	double* sampleResult = new double[NODE_COUNT + 1];
	int* degrees = new int[NODE_COUNT + 1];
	int* candidateDegrees = new int[NODE_COUNT + 1];
	initArray(candidateDegrees, NODE_COUNT + 1);
	srand((unsigned)time(NULL));
	int maxDegree = 0;
	int edgeNum = 0;
	int newEdgeNum = 0;
	int nodeNum = 0;
	int *nodes = new int[NODE_COUNT + 1];
	int* newModelNode = new int[NODE_COUNT + 1];
	int* newModelNodeEarly = new int[NODE_COUNT + 1];
	int* kddNode = new int[NODE_COUNT + 1];
	int* kddUpdatedNode = new int[NODE_COUNT + 1];
	int* weighedNode = new int[NODE_COUNT + 1];
	int* sampleKddresultNode = new int[NODE_COUNT + 1];
	int* resortNode = new int[NODE_COUNT + 1];
	int* kStartIndex = new int[NODE_COUNT + 1];
	int* components = new int[NODE_COUNT + 1];
	int no_components = 0;

	Edge *edges = new Edge[EDGE_COUNT + 1];
	Edge *weighedEdges = new Edge[EDGE_COUNT + 1];
	Edge *kddUpdatedEdges = new Edge[EDGE_COUNT + 1];
	initPariArray(kddUpdatedEdges, EDGE_COUNT + 1);
	initArray(nodes, NODE_COUNT + 1);
	initArray(kddUpdatedNode, NODE_COUNT + 1);
	initPariArray(weighedEdges, EDGE_COUNT + 1);
	initPariArray(edges, EDGE_COUNT + 1);
	initDoubleArray(sampleResult, NODE_COUNT + 1);
	initArray(resortNode, NODE_COUNT + 1);
	initArray(kStartIndex, NODE_COUNT + 1);
	int kddUpdatedEdgeNum = 0;
	loadExistData(dataset, nodes, edges, nodeNum, edgeNum);

	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
		kddUpdatedEdges[i].x = edges[i].x;
		kddUpdatedEdges[i].y = edges[i].y;
		kddUpdatedEdges[i].p = edges[i].p;
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		candidateDegrees[i] = degrees[i];
	}
	newEdgeNum = edgeNum;
	kddUpdatedEdgeNum = edgeNum;

	//kddCoreDecompositionOriginSpeedUp(kddUpdatedEdgeNum, kddUpdatedEdges, maxDegree, threshold, nodeNum, k, degrees);
	//addKddNodes(kddUpdatedEdges, nodeNum, kddUpdatedEdgeNum, kddUpdatedNode);
	//outputNodes("kddresult.txt", kddUpdatedNode, nodeNum);
	//cout << "kddCoreUpdate" << endl;



	double dur;
	clock_t preStart, start, end, end2, markovEnd;
	preStart = clock();
	//certainCoreDecomposition(edges, nodeNum, edgeNum, k, resortNode, kStartIndex);
	certainCoreDecompositionSpeedUp(edges, nodeNum, edgeNum, k, resortNode, kStartIndex, components, no_components);
	//update nodeState
	cout << nodeNum << " nodes" << endl;
	int* nodeState = new int[nodeNum + 1];
	initArrayWithValue<int>(nodeState, nodeNum + 1, PRUNED);
	for (int i = 0; i < edgeNum; i++)
	{
		nodeState[edges[i].x] = TOCONFIRM;
		nodeState[edges[i].y] = TOCONFIRM;
	}
	//
	cout << "certain core decomposition end" << endl;
	for (int i = 0; i < edgeNum; i++)
	{
		weighedEdges[i].x = edges[i].x;
		weighedEdges[i].y = edges[i].y;
		weighedEdges[i].p = edges[i].p;
	}
	newEdgeNum = edgeNum;
	start = clock();
	dur = (double)(start - preStart);
	certainDecompositionTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	int afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		kddNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x >= 0 && edges[i].y >= 0)
		{
			kddNode[edges[i].x] = 1;
			kddNode[edges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		if (kddNode[i] == 1)
		{
			afternum++;
		}
	}
	initArray(kddNode, NODE_COUNT + 1);

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	//newModelDecompositionChainNoOrder(edges, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon);
	//addNewModelNodes(newModelNode, threshold, sampleResult, nodeNum);

	//cout << "new model no order end" << endl;


	// new a orderEdge to be pruned in upper bound and use in approximate algorithm without GT
	orderEdge* oEdge = new orderEdge[edgeNum + 1];
	for (int i = 0; i < edgeNum; i++)
	{
		oEdge[i].x = edges[i].x;
		oEdge[i].y = edges[i].y;
		oEdge[i].p = edges[i].p;
		oEdge[i].edgeIndex = i;
	}
	end = clock();
	//end of init orderEdge oEdge

	dur = (double)(end - start);
	naiveTime = dur / CLOCKS_PER_SEC;
	//printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	//markov inequality to reduce candidate

	int noden = kddCoreDecompositionOriginSpeedUpMarkovInequalityWithNodeStateRemoveEdges(newEdgeNum, oEdge, maxDegree, threshold, nodeNum, k, candidateDegrees, nodeState);
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << sampleSize << " samples in total" << endl;
	cout << newEdgeNum << "new edges" << endl;
	//////
	//init all the varible needed in  our doule early terminate program according to noden
	int sizeToConfrimNodes = 0;//store the num of nodes remaining to be confirm
	int* curNodeState = new int[nodeNum + 1];
	copyArray<int>(nodeState, curNodeState, nodeNum + 1);
	queue<unsigned> nodeQueue;//store active nodes
	short* allEdgeState = new short[(edgeNum + 1)*(sampleSize + 1)]; //allEdgeState[i*(edgenum+1)+j] means sample i , edge j
	initArrayWithValue<short>(allEdgeState, (edgeNum + 1)*(sampleSize + 1), -1);
	int* allNodeState = new int[(nodeNum + 1)*(sampleSize + 1)]; //allNodeState[i*(nodeNum+1)+j] means sample i , node j

	upLowNum* nodeUL = new upLowNum[(sampleSize + 1)*(nodeNum + 1)]; // nodeUL[i*(nodeNum+1)+j] means sample i , node j

	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int i = 0; i < sampleSize; i++)
	{
		for (int j = 0; j <= nodeNum; j++)
		{
			nodeUL[i*(nodeNum + 1) + j].remainingEdges = degrees[j];
			nodeUL[i*(nodeNum + 1) + j].curEdges = 0;
			nodeUL[i*(nodeNum + 1) + j].solidEdges = 0;
		}
	}
	//initArrayWithValue<int>(allNodeState, (nodeNum + 1)*(sampleSize + 1),TOCONFIRM);

	for (int i = 0; i < sampleSize; i++)
	{
		for (int j = 0; j <= nodeNum; j++)
		{
			if (nodeState[j] != PRUNED)
			{
				allNodeState[i*(nodeNum + 1) + j] = TOCONFIRM;
			}
			else
			{
				allNodeState[i*(nodeNum + 1) + j] = nodeState[j];
			}
		}
	}

	//nodeState to find candidate nodes 1 means in result, 0 means not in, -1 means to be confirm
	/////


	/*int minusNum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
	if (nodeState[i] == -1)
	{
	minusNum++;
	}
	}
	cout << minusNum << "nodes to be " << endl;*/
	markovEnd = clock();
	dur = (double)(markovEnd - end);
	markovTime = dur / CLOCKS_PER_SEC;
	printf("markov inequality used time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "markov candidate" << noden << endl;
	cout << edgeNum << "before node state" << endl;
	for (int i = 0; i <= nodeNum; i++)
	{
		sampleResult[i] = 0;
	}


	clock_t tempS, tempE;
	tempS = clock();

	newModelDecompositionEarlyStopWithoutEdgeOrderWithNodeState(oEdge, nodeNum, newEdgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden, nodeState, allEdgeState, allNodeState, nodeUL, edgeNum);
	addNewModelNodes(newModelNode, threshold, sampleResult, nodeNum);
	cout << nodeNum << " nodes" << endl;

	tempE = clock();
	dur = (double)(tempE - tempS);
	double alTime = dur / CLOCKS_PER_SEC;
	printf("al Use Time:%f\n", (dur / CLOCKS_PER_SEC));

	//update node state
	for (int i = 0; i <= nodeNum; i++)
	{
		if (sampleResult[i] >= threshold)
		{
			nodeState[i] = CONFIRMED;
		}
	}
	//
	// to finish our doule early terminate algorithms
	// init oEdge to original edges
	for (int i = 0; i < edgeNum; i++)
	{
		oEdge[i].x = edges[i].x;
		oEdge[i].y = edges[i].y;
		oEdge[i].p = edges[i].p;
		oEdge[i].edgeIndex = i;
	}
	//
	newModelDecompositionEarlyStopWithoutEdgeOrderStateTransfer(oEdge, nodeNum, edgeNum, k, sampleResult, resortNode, kStartIndex, delta, epsilon, noden, nodeState, allEdgeState, allNodeState, nodeUL, threshold, newModelNodeEarly);







	//addNewModelNodes(newModelNodeEarly, threshold, sampleResult, nodeNum);

	cout << "new model end" << endl;

	end2 = clock();
	dur = (double)(end2 - tempS);
	newModelTime = dur / CLOCKS_PER_SEC;
	printf("Use Time:%f\n", (dur / CLOCKS_PER_SEC));
	cout << "newModel" << endl;
	double result = checkResult(newModelNodeEarly, newModelNode, nodeNum);


	cout << "threshold" << threshold << "k || " << k << " result|| " << result << endl;

	if (changeKOrThreshold == 'k')
	{
		outFile << k << '\t' << (alTime + certainDecompositionTime + markovTime) << '\t' << (markovTime + certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else if (changeKOrThreshold == 't')
	{
		outFile << threshold << '\t' << (alTime + certainDecompositionTime + markovTime) << '\t' << (markovTime + certainDecompositionTime + newModelTime) << '\t' << result << endl;
	}
	else
	{
		cout << "error in changeKOrThreshold" << endl;
	}
	double temp = 0;

	//system("pause");;
	//int no_components = 0;




	//delete[] kddUpdatedNode;
	delete[] newModelNodeEarly;
	delete[] candidateDegrees;
	delete[] components;
	delete[] kddUpdatedEdges;
	delete[] sampleKddresultNode;
	delete[] sampleResult;
	delete[] newModelNode;
	//delete[] kddNode;
	delete[] nodes;
	delete[] edges;
	delete[] degrees;
	delete[] weighedEdges;
	delete[] weighedNode;
	delete[] resortNode;
	delete[] kStartIndex;
}


/*
task 1 computes difference between new model and kdd model
task 2 computes difference between expected result of new model and weighted model
task 3 computes time and difference between naive and new model
task 4 computes original, certainDecomposition and upperbound candidate size
task 5 computes time and difference between naive and using result candidate as sample candidate
task 6 computes time of original, only core value order, upper bound markov and early terminate method
task 7 computes time of naive method upper boundand double early terminate algorithm
task 8 computes time of naive method(without core decomposition), early terminate and speed-up-3
task 9 computes time of naive method(without core decomposition), speed-up-2 and speed-up-3
*/
////////// end of experiment functions

template<typename T> void copyArray(T* source, T*destination, int len)
{
	for (int i = 0; i < len; i++)
	{
		destination[i] = source[i];
	}
}

double randP()
{

	return (double)rand() / RAND_MAX;
}

void addWeighedNodes(Edge* edges, int nodeNum, int edgeNum, int* weighedNode)
{
	for (int i = 0; i <= nodeNum; i++)
	{
		weighedNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		weighedNode[edges[i].x] = 1;
		weighedNode[edges[i].y] = 1;
	}
	return;
}

void findUncertainDegree(Edge* edges, int nodeNum, int edgeNum, double* degrees)
{
	initDoubleArray(degrees, nodeNum + 1);
	for (int i = 0; i < edgeNum; i++)
	{
		degrees[edges[i].x] += edges[i].p;
		degrees[edges[i].y] += edges[i].p;
	}
	return;
}

void weighedCoreDecomposition(int& edgeNum, Edge* edges, double threshold, int nodeNum, int k, int* degrees)
{
	//double* X = new double[NODE_COUNT*(maxDegree + 2)];
	double* degreeUncertain = new double[nodeNum + 1];
	int newEdgeNum = 0;
	//findUncertainDegree(edges, nodeNum, edgeNum, degreeUncertain);
	bool updated = true;
	while (edgeNum != newEdgeNum && edgeNum != 0 && updated)
	{
		updated = false;;
		findUncertainDegree(edges, nodeNum, edgeNum, degreeUncertain);
		newEdgeNum = edgeNum;
		for (int j = 0; j < edgeNum;)
		{
			if (degreeUncertain[edges[j].x] < k || degreeUncertain[edges[j].y] < k || degrees[edges[j].y] < k || degrees[edges[j].x] < k)
			{
				degreeUncertain[edges[j].x] -= edges[j].p;
				degreeUncertain[edges[j].y] -= edges[j].p;
				edges[j].x = edges[edgeNum - 1].x;
				edges[j].y = edges[edgeNum - 1].y;
				edges[j].p = edges[edgeNum - 1].p;
				edgeNum--;
				updated = true;
				continue;
			}
			j++;
		}
		//clacNodeP(X,maxDegree);
	}
	delete[] degreeUncertain;
	//delete[] X;
	return;

}


double checkResult(int* newModelNodes, int* kddNodes, int nodeNum)
{
	int unionNodes = 0;
	int minusNodes = 0;
	int commonNodes = 0;
	int firstNodes = 0;
	int secondNodes = 0;
	double result = 0;
	for (int i = 1; i <= nodeNum; i++)
	{
		if (newModelNodes[i] + kddNodes[i] == 2)
		{
			unionNodes++;
			commonNodes++;
			//cout << "common " << i << "||  ";
		}
		else if (newModelNodes[i] + kddNodes[i] == 1)
		{
			minusNodes++;
			unionNodes++;
			if (kddNodes[i] == 1)
			{
				secondNodes++;
				//cout << "2nd method " << i << endl;
			}
			if (newModelNodes[i] == 1)
			{
				firstNodes++;
				//cout << "1st method " << i << endl;
			}
		}
		else if (newModelNodes[i] + kddNodes[i] != 0)
		{
			cout << "nodes values error in check result" << endl;
		}
	}
	if (unionNodes == 0)
	{
		cout << "unidonNodes equal to 0" << endl;
		return 0;
	}
	else
	{
		cout << "1st " << firstNodes << "2nd " << secondNodes << " common nodes" << commonNodes << endl;
		cout << minusNodes << " / " << unionNodes << endl;
		result = double(minusNodes) / double(unionNodes);
		return result;
	}
}

void addKddNodes(Edge* edges, int nodeNum, int edgeNum, int* kddNode)
{
	for (int i = 0; i <= nodeNum; i++)
	{
		kddNode[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		kddNode[edges[i].x] = 1;
		kddNode[edges[i].y] = 1;
	}
	return;
}

void addNewModelNodes(int* newModelNodes, double threshold, double* sampleResult, int nodeNum)
{
	for (int i = 1; i <= nodeNum; i++)
	{
		if (sampleResult[i] >= threshold)
		{
			newModelNodes[i] = 1;
		}
		else
		{
			newModelNodes[i] = 0;
		}
	}
	return;
}

void addSampleResultsEdgeStateExpectedValue(Edge* cerEdges, int edgeState[], int cerEdgesNum, int nodeNum, double* sampleResult, int k, int maxdegree)
{
	int* tempResult = new int[nodeNum + 1];
	initArray(tempResult, nodeNum + 1);
	for (int i = 0; i < cerEdgesNum; i++)
	{
		if (edgeState[i] == 1)
		{
			tempResult[cerEdges[i].x] = 1;
			tempResult[cerEdges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		sampleResult[k*(nodeNum + 1) + i] += tempResult[i];
	}
	delete[] tempResult;
	return;
}

void addSampleResultsEdgeStateWithAllNodeState(orderEdge* cerEdges, int edgeState[], int cerEdgesNum, int nodeNum, double* sampleResult, int* allNodeState, int sampleTime)
{
	int* tempResult = new int[nodeNum + 1];
	initArray(tempResult, nodeNum + 1);
	for (int i = 0; i < cerEdgesNum; i++)
	{
		if (edgeState[i] == 1)
		{
			tempResult[cerEdges[i].x] = 1;
			tempResult[cerEdges[i].y] = 1;
		}
	}
	for (int i = 0; i <= nodeNum; i++)
	{
		sampleResult[i] += tempResult[i];
		if (tempResult[i] == 1)
		{
			allNodeState[sampleTime*(nodeNum + 1) + i] = CONFIRMED;
		}
	}
	delete[] tempResult;
	return;
}


void addSampleResultsEdgeState(orderEdge* cerEdges, int edgeState[], int cerEdgesNum, int nodeNum, double* sampleResult)
{
	int* tempResult = new int[nodeNum + 1];
	initArray(tempResult, nodeNum + 1);
	for (int i = 0; i < cerEdgesNum; i++)
	{
		if (edgeState[i] == 1)
		{
			tempResult[cerEdges[i].x] = 1;
			tempResult[cerEdges[i].y] = 1;
		}
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] += tempResult[i];
	}
	delete[] tempResult;
	return;
}


void addSampleResultsEdgeState(Edge* cerEdges, int edgeState[], int cerEdgesNum, int nodeNum, double* sampleResult)
{
	int* tempResult = new int[nodeNum + 1];
	initArray(tempResult, nodeNum + 1);
	for (int i = 0; i < cerEdgesNum; i++)
	{
		if (edgeState[i] == 1)
		{
			tempResult[cerEdges[i].x] = 1;
			tempResult[cerEdges[i].y] = 1;
		}
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] += tempResult[i];
	}
	delete[] tempResult;
	return;
}

void addSampleResults(Edge* cerEdges, int cerEdgesNum, int nodeNum, double* sampleResult)
{
	int* tempResult = new int[nodeNum + 1];
	initArray(tempResult, nodeNum + 1);
	for (int i = 0; i < cerEdgesNum; i++)
	{
		tempResult[cerEdges[i].x] = 1;
		tempResult[cerEdges[i].y] = 1;
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] += tempResult[i];
	}
	delete[] tempResult;
	return;
}


void newModelDecompositionExpected(Edge* edges, int nodeNum, int edgeNum, int resultNode[], int originMaxDegree, int thresholdK)
{
	double* pNode = new double[originMaxDegree + 1];
	int sampleSize = 100000;
	int* tempResult = new int[NODE_COUNT + 1];
	initDoubleArray(pNode, originMaxDegree + 1);
	initArray(tempResult, NODE_COUNT + 1);
	int* sampleStatistic = new int[(originMaxDegree + 1)*(NODE_COUNT + 1)];
	initArray(sampleStatistic, (originMaxDegree + 1)*(NODE_COUNT + 1));
	//initDoubleArray(sampleResult, nodeNum + 1);
	int cerEdgeNum = 0;
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	Edge* cerEdges = new Edge[edgeNum + 1];
	initPariArray(cerEdges, edgeNum + 1);
	//	int maxDegree = findMAxDegree(cerEdges, nodeNum, cerEdgeNum, degrees);

	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		cerEdgeNum = 0;
		int newEdgeNum = 0;
		//int maxDegree = findMAxDegree(edges,nodeNum,cerEdgeNum,degrees);
		for (int i = 0; i < edgeNum; i++)
		{
			if (randP() <= edges[i].p)
			{
				cerEdges[cerEdgeNum].x = edges[i].x;
				cerEdges[cerEdgeNum].y = edges[i].y;
				cerEdges[cerEdgeNum++].p = 1;
			}

		}
		int maxDegree = findMAxDegree(cerEdges, nodeNum, cerEdgeNum, degrees);
		for (int k = 1; k <= originMaxDegree; k++)
		{
			newEdgeNum = 0;
			while (newEdgeNum != cerEdgeNum && cerEdgeNum != 0)
			{
				newEdgeNum = cerEdgeNum;
				for (int j = 1; j <= nodeNum; j++)
				{
					if (degrees[j] < k && degrees[j] != 0)
					{
						//delete all the egdge which contains node j
						for (int w = 0; w < cerEdgeNum;)
						{
							if (cerEdges[w].x == j || cerEdges[w].y == j)
							{
								degrees[cerEdges[w].x] --;
								degrees[cerEdges[w].y] --;
								cerEdges[w].x = cerEdges[cerEdgeNum - 1].x;
								cerEdges[w].y = cerEdges[cerEdgeNum - 1].y;
								cerEdges[w].p = cerEdges[cerEdgeNum - 1].p;
								cerEdgeNum--;
								continue;
							}
							w++;
						}
						//maxDegree = findMAxDegree(cerEdges, nodeNum, cerEdgeNum, degrees);
					}
				}
			}
			initArray(tempResult, NODE_COUNT + 1);
			for (int w = 0; w < cerEdgeNum; w++)
			{
				tempResult[cerEdges[w].x] = 1;
				tempResult[cerEdges[w].y] = 1;
			}
			for (int w = 1; w <= NODE_COUNT; w++)
			{
				sampleStatistic[w*(originMaxDegree + 1) + k] += tempResult[w];
			}
		}
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		cout << endl;
		cout << "node num:" << i << " || ";
		initDoubleArray(pNode, originMaxDegree + 1);
		sampleStatistic[i*(originMaxDegree + 1)] = sampleSize;
		for (int j = 0; j < originMaxDegree; j++)
		{
			pNode[j] = (sampleStatistic[(originMaxDegree + 1)*i + j] - sampleStatistic[(originMaxDegree + 1)*i + j + 1]) / double(sampleSize);
		}
		pNode[originMaxDegree] = sampleStatistic[(originMaxDegree + 1)*i + originMaxDegree] / double(sampleSize);
		double expectedNode = 0;
		cout << " 0 " << " || " << pNode[0] << " , ";
		for (int l = 1; l <= originMaxDegree; l++)
		{
			cout << " l " << l << " || " << pNode[l] << " , ";
			expectedNode += l * pNode[l];
		}
		if (expectedNode >= thresholdK)
		{
			resultNode[i] = 1;
		}
		else {
			resultNode[i] = 0;
		}
	}

	//
	delete[] pNode;
	delete[] tempResult;
	delete[] sampleStatistic;
	delete[] degrees;
	delete[] cerEdges;
	return;
}

void newModelDecompositionChain(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex)
{

	int sampleSize = 1000;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);


	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{
		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;

		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		if (nodeC[edges[i].x].next == NULL)
		{
			nodeC[edges[i].x].next = temp0;
		}
		else if (edges[i].p <= edges[nodeC[edges[i].x].next->edgeIndex].p)
		{
			temp0->next = nodeC[edges[i].x].next;
			nodeC[edges[i].x].next = temp0;

		}
		else
		{
			tempChain = nodeC[edges[i].x].next;
			tempChainPre = tempChain;
			while (tempChain != NULL && edges[i].p > edges[tempChain->edgeIndex].p)
			{
				tempChainPre = tempChain;
				tempChain = tempChain->next;
			}
			temp0->next = tempChain;
			if (tempChainPre != NULL)
			{
				tempChainPre->next = temp0;
			}
			else
			{
				cout << "tempChainPre is null in temp0" << endl;
			}
		}
		if (nodeC[edges[i].y].next == NULL)
		{
			nodeC[edges[i].y].next = temp1;
		}
		else if (edges[i].p <= edges[nodeC[edges[i].y].next->edgeIndex].p)
		{
			temp1->next = nodeC[edges[i].y].next;
			nodeC[edges[i].y].next = temp1;

		}
		else
		{
			tempChain = nodeC[edges[i].y].next;
			tempChainPre = tempChain;
			while (tempChain != NULL && edges[i].p > edges[tempChain->edgeIndex].p)
			{
				tempChainPre = tempChain;
				tempChain = tempChain->next;
			}
			temp1->next = tempChain;
			if (tempChainPre != NULL)
			{
				tempChainPre->next = temp1;
			}
			else
			{
				cout << "tempChainPre is not null" << endl;
			}
		}
	}



	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int i = 0; i <= nodeNum; i++)//for (int j = kStartIndex[k-1] + 1; j <= nodeNum; j++)
		{
			//int i = resortNode[j];
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				/*if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
				//early stop
				edgeState[tempChain->edgeIndex] = 0;
				nodeC[i].remainingEdges--;
				nodeC[tempChain->node].remainingEdges--;
				tempChain = tempChain->next;
				continue;
				}*/
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	return;
}

int calcSampleTimes(double delta, double epsilon, int nodeNum)
{
	//double deltaF = 1.0 - pow((1 - delta), (1.0 / double(nodeNum)));
	if (nodeNum != 0)
	{
		double deltaF = delta / double(nodeNum);
		int sampleTime = ceil(1 / (2 * epsilon*epsilon)*log(2 / deltaF));
		return sampleTime;
	}
	else
	{
		return 0;
	}
}

int caclTotalNodeNum(int edgeNum, int nodeNum, Edge* edges)
{
	int* node = new int[nodeNum + 1];
	initArray(node, nodeNum + 1);
	for (int i = 0; i < edgeNum; i++)
	{
		node[edges[i].x] = 1;
		node[edges[i].y] = 1;
	}
	int nodeN = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (node[i] == 1)
		{
			nodeN++;
		}
	}
	return nodeN;
}

void newModelDecompositionChainNoOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon)
{
	int noden = caclTotalNodeNum(edgeNum, nodeNum, edges);
	cout << "no order num" << noden << endl;
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "no order sample size " << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
	}



	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int i = 0; i <= nodeNum; i++)//for (int j = kStartIndex[k-1] + 1; j <= nodeNum; j++)
		{
			//int i = resortNode[j];
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				/*if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
				//early stop
				edgeState[tempChain->edgeIndex] = 0;
				nodeC[i].remainingEdges--;
				nodeC[tempChain->node].remainingEdges--;
				tempChain = tempChain->next;
				continue;
				}*/
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	return;
}


void newModelDecompositionChainNoOrderWithCoreOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon)
{
	int noden = caclTotalNodeNum(edgeNum, nodeNum, edges);
	cout << "no order num" << noden << endl;
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "no order sample size " << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
	}



	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int j = kStartIndex[k - 1] + 1; j <= nodeNum; j++)
		{
			int i = resortNode[j];
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				/*if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
				//early stop
				edgeState[tempChain->edgeIndex] = 0;
				nodeC[i].remainingEdges--;
				nodeC[tempChain->node].remainingEdges--;
				tempChain = tempChain->next;
				continue;
				}*/
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	return;
}


void newModelDecompositionChainNoOrderClacNoden(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden)
{
	cout << "no order num" << noden << endl;
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "no order sample size " << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
	}



	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int i = 0; i <= nodeNum; i++)//for (int j = kStartIndex[k-1] + 1; j <= nodeNum; j++)
		{
			//int i = resortNode[j];
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				/*if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
				//early stop
				edgeState[tempChain->edgeIndex] = 0;
				nodeC[i].remainingEdges--;
				nodeC[tempChain->node].remainingEdges--;
				tempChain = tempChain->next;
				continue;
				}*/
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	return;
}



void certainCoreDecompositionSpeedUp(Edge* edges, int nodeNum, int& edgeNum, int k, int* resortNode, int* kStartIndex, int* components, int& no_components)
{
	int tempEdgeNum = edgeNum;
	bool coutMaxCoreValue = false;
	//int* resortNode = new int[nodeNum+ 1];
	int curNodeIndex = 0;
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	initArray(resortNode, nodeNum + 1);
	Edge* tempEdges = new Edge[edgeNum + 1];
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	//int* kStartIndex = new int[maxDegree];
	kStartIndex[0] = -1;

	for (int i = 0; i < edgeNum; i++)
	{
		tempEdges[i].x = edges[i].x;
		tempEdges[i].y = edges[i].y;
		tempEdges[i].p = edges[i].p;
	}
	int kEdgeNum = edgeNum;
	int newEdgeNum = 0;

	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;

	for (int i = 0; i < edgeNum; i++)
	{
		edgeState[i] = 1;
	}

	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;


	}
	newEdgeNum = 0;
	bool updated = true;
	bool updateEdges = false;
	for (int i = 1; i <= maxDegree; i++)
	{
		if (!coutMaxCoreValue && tempEdgeNum == 0)
		{
			cout << "max core value is " << i << endl;
			coutMaxCoreValue = true;
		}

		if (i == k && (!updateEdges))
		{
			for (int w = 0; w < edgeNum; w++)
			{
				if (edgeState[w] == 1)
				{
					tempEdges[newEdgeNum].x = edges[w].x;
					tempEdges[newEdgeNum].y = edges[w].y;
					tempEdges[newEdgeNum++].p = edges[w].p;
				}
			}

			edgeNum = newEdgeNum;
			for (int w = 0; w < edgeNum; w++)
			{
				edges[w].x = tempEdges[w].x;
				edges[w].y = tempEdges[w].y;
				edges[w].p = tempEdges[w].p;
			}
			updateEdges = true;
		}
		//cout << i << endl;
		updated = true;
		while (updated)
		{
			updated = false;
			//newEdgeNum = edgeNum;
			for (int j = 0; j <= nodeNum; j++)
			{
				if (degrees[j] <= i && degrees[j] != 0)
				{
					updated = true;
					//delete all the egdge which contains node j
					kStartIndex[i] = curNodeIndex;
					resortNode[curNodeIndex++] = j;
					earlyStopChain* tempChain = nodeC[j].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						degrees[j] --;
						tempEdgeNum--;
						degrees[tempChain->node] --;
						edgeState[tempChain->edgeIndex] = 0;
						tempChain = tempChain->next;
					}
					/*for (int w = 0; w < edgeNum;)
					{
					if (tempEdges[w].x == j || tempEdges[w].y == j)
					{
					degrees[tempEdges[w].x] --;
					degrees[tempEdges[w].y] --;
					tempEdges[w].x = tempEdges[edgeNum - 1].x;
					tempEdges[w].y = tempEdges[edgeNum - 1].y;
					tempEdges[w].p = tempEdges[edgeNum - 1].p;
					edgeNum--;
					if (i < k)
					{
					edges[w].x = edges[kEdgeNum - 1].x;
					edges[w].y = edges[kEdgeNum - 1].y;
					edges[w].p = edges[kEdgeNum - 1].p;
					kEdgeNum--;
					}
					continue;
					}
					w++;
					}*/
					//maxDegree = findMAxDegree(cerEdges, nodeNum, cerEdgeNum, degrees);
				}
			}
		}
	}
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	/*int component = countComponents(nodeNum, edges, edgeNum,degrees);
	cout << component << " in total component" << endl;
	int w = caclTotalNodeNum(edgeNum, nodeNum, edges);
	cout << w << " nodes in total" << endl;
	*/

	//compute component
	/*
	delete[] nodeC;
	nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	for (int i = 0; i < edgeNum; i++)
	{

	earlyStopChain* temp0 = new earlyStopChain;
	earlyStopChain* temp1 = new earlyStopChain;
	//earlyStopChain* temp2 = new earlyStopChain;
	//from small to large insert

	//cout << i << endl;
	temp0->node = edges[i].y;
	edgeP[i] = edges[i].p;
	temp0->edgeIndex = i;
	temp1->node = edges[i].x;
	temp1->edgeIndex = i;
	temp0->next = nodeC[edges[i].x].next;
	nodeC[edges[i].x].next = temp0;
	temp1->next = nodeC[edges[i].y].next;
	nodeC[edges[i].y].next = temp1;


	}

	//int* components = new int[nodeNum + 1];
	//cout << 0 << " " << degrees[0] << endl;
	no_components = findOutConnectedCompoent(components, nodeNum, edges, edgeNum, degrees, nodeC);
	//	int findOutConnectedCompoent(int* components, int n, Edge* edges, int edgeNum, int* degrees, earlyStopChainHead* nodeC)

	cout << "number of compoents" << no_components << endl;
	*/

	//free nodeC

	for (int i = 0; i <= NODE_COUNT; i++)
	{
		tempChain = nodeC[i].next;
		while (tempChain != NULL)
		{
			tempChainPre = tempChain->next;
			delete tempChain;
			tempChain = tempChainPre;
		}
	}

	delete[] nodePs;
	delete[] tempEdges;
	delete[] tempEdge;
	delete[] degrees;
	delete[] nodeC;
	delete[] edgeState;
	delete[] edgeP;
	//delete temp0;
	//delete temp1;
	//delete temp2;
	//delete[] resortNode;
	//	delete[] kStartIndex;
}



void certainCoreDecomposition(Edge* edges, int nodeNum, int& edgeNum, int k, int* resortNode, int* kStartIndex)
{
	//int* resortNode = new int[nodeNum+ 1];
	int curNodeIndex = 0;
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	initArray(resortNode, nodeNum + 1);
	Edge* tempEdges = new Edge[edgeNum + 1];


	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	//int* kStartIndex = new int[maxDegree];
	kStartIndex[0] = -1;

	for (int i = 0; i < edgeNum; i++)
	{
		tempEdges[i].x = edges[i].x;
		tempEdges[i].y = edges[i].y;
		tempEdges[i].p = edges[i].p;
	}
	bool maxCoreValueUpdate = false;
	int kEdgeNum = edgeNum;
	int newEdgeNum = 0;
	for (int i = 1; i <= maxDegree; i++)
	{
		//cout << i << endl;
		if (edgeNum == 0 && !maxCoreValueUpdate)
		{
			cout << "withour speed up max core value is " << i << endl;
			maxCoreValueUpdate = true;
		}
		newEdgeNum = 0;
		while (newEdgeNum != edgeNum)
		{
			newEdgeNum = edgeNum;
			for (int j = 0; j <= nodeNum; j++)
			{
				if (degrees[j] <= i && degrees[j] != 0)
				{
					//delete all the egdge which contains node j
					kStartIndex[i] = curNodeIndex;
					resortNode[curNodeIndex++] = j;
					for (int w = 0; w < edgeNum;)
					{
						if (tempEdges[w].x == j || tempEdges[w].y == j)
						{
							degrees[tempEdges[w].x] --;
							degrees[tempEdges[w].y] --;
							tempEdges[w].x = tempEdges[edgeNum - 1].x;
							tempEdges[w].y = tempEdges[edgeNum - 1].y;
							tempEdges[w].p = tempEdges[edgeNum - 1].p;
							edgeNum--;
							if (i < k)
							{
								edges[w].x = edges[kEdgeNum - 1].x;
								edges[w].y = edges[kEdgeNum - 1].y;
								edges[w].p = edges[kEdgeNum - 1].p;
								kEdgeNum--;
							}
							continue;
						}
						w++;
					}
					//maxDegree = findMAxDegree(cerEdges, nodeNum, cerEdgeNum, degrees);
				}
			}
		}
	}
	edgeNum = kEdgeNum;
	delete[] tempEdges;
	delete[] degrees;
	//delete[] resortNode;
	//	delete[] kStartIndex;
}

void newModelDecompositionEarlyStop(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden)
{
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "new mode sample size" << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	bool earlyStop = false;
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{
		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;

		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		if (nodeC[edges[i].x].next == NULL)
		{
			nodeC[edges[i].x].next = temp0;
		}
		else if (edges[i].p <= edges[nodeC[edges[i].x].next->edgeIndex].p)
		{
			temp0->next = nodeC[edges[i].x].next;
			nodeC[edges[i].x].next = temp0;

		}
		else
		{
			tempChain = nodeC[edges[i].x].next;
			tempChainPre = tempChain;
			while (tempChain != NULL && edges[i].p > edges[tempChain->edgeIndex].p)
			{
				tempChainPre = tempChain;
				tempChain = tempChain->next;
			}
			temp0->next = tempChain;
			if (tempChainPre != NULL)
			{
				tempChainPre->next = temp0;
			}
			else
			{
				cout << "tempChainPre is null in temp0" << endl;
			}
		}
		if (nodeC[edges[i].y].next == NULL)
		{
			nodeC[edges[i].y].next = temp1;
		}
		else if (edges[i].p <= edges[nodeC[edges[i].y].next->edgeIndex].p)
		{
			temp1->next = nodeC[edges[i].y].next;
			nodeC[edges[i].y].next = temp1;

		}
		else
		{
			tempChain = nodeC[edges[i].y].next;
			tempChainPre = tempChain;
			while (tempChain != NULL && edges[i].p > edges[tempChain->edgeIndex].p)
			{
				tempChainPre = tempChain;
				tempChain = tempChain->next;
			}
			temp1->next = tempChain;
			if (tempChainPre != NULL)
			{
				tempChainPre->next = temp1;
			}
			else
			{
				cout << "tempChainPre is not null" << endl;
			}
		}
	}



	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int j = kStartIndex[k - 1] + 1; j <= nodeNum; j++)
		{
			int i = resortNode[j];
			earlyStop = false;
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
					//early stop
					earlyStop = true;
					break;
				}
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
			//early stop
			if (earlyStop)
			{
				tempChain = nodeC[i].next;
				while (tempChain != NULL)
				{
					if (edgeState[tempChain->edgeIndex] == -1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
					else if (edgeState[tempChain->edgeIndex] == 1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
					}
					tempChain = tempChain->next;

				}
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	return;
}


void newModelDecompositionEarlyStopWithoutEdgeOrderWithoutCoreValue(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden)
{
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "new mode sample size" << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	bool earlyStop = false;
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;


	}

	//cacluate components
	/*
	int* components = new int[nodeNum + 1];
	cout << 0 << " " << degrees[0] << endl;
	int no_compoents = findOutConnectedCompoent(components,nodeNum,edges,edgeNum,degrees,nodeC);

	cout << "number of compoents" << no_compoents << endl;
	*/
	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int i = 0; i <= nodeNum; i++)
		{

			earlyStop = false;
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
					//early stop
					earlyStop = true;
					break;
				}
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
			//early stop
			if (earlyStop)
			{
				tempChain = nodeC[i].next;
				while (tempChain != NULL)
				{
					if (edgeState[tempChain->edgeIndex] == -1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
					else if (edgeState[tempChain->edgeIndex] == 1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
					}
					tempChain = tempChain->next;

				}
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	//delete[] components;

	//free nodeC

	for (int i = 0; i <= NODE_COUNT; i++)
	{
		tempChain = nodeC[i].next;
		while (tempChain != NULL)
		{
			tempChainPre = tempChain->next;
			delete tempChain;
			tempChain = tempChainPre;
		}
	}


	delete[] edgeState;
	delete[] edgeP;
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	delete[] nodeC;
	return;
}

void newModelDecompositionEarlyStopWithoutEdgeOrderStateTransfer
(orderEdge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden, int* nodeState, short* allEdgeState, int* allNodeState, upLowNum* nodeUL, double threshold, int* result)
{
	int candidateNum = 0;
	queue<int> candidateSet;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (nodeState[i] == TOCONFIRM)
		{
			candidateSet.push(i);
		}
	}

	cout << candidateSet.size() << " candidates " << endl;
	candidateNum = candidateSet.size();
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "new mode sample size" << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	int* earlyS = new int[(nodeNum + 1)*(sampleSize + 1)];
	initArray(earlyS, (nodeNum + 1)*(sampleSize + 1));



	bool earlyStop = false;
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChain2;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;


	}



	clock_t cStart, cEnd;
	double dur2;
	cStart = clock();
	//for v in candidate set C, only consider and sample neighbor edges
	/*queue<int> tempCdt(candidateSet);
	while (!tempCdt.empty())
	{

	int i = tempCdt.front();
	tempCdt.pop();

	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
	if (allNodeState[sampleTime*(nodeNum + 1) + i] != TOCONFIRM)// only compute nodes need to confirm at this round
	{
	continue;
	}
	//cout << sampleTime << endl;
	nodeUL[sampleTime*(nodeNum + 1) + i].solidEdges = 0;
	earlyStop = false;
	tempChain = nodeC[i].next;
	while (tempChain != NULL)//test all the neighbor edges of node i
	{
	if (allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] != E_TOCOMFIRM)
	{
	//ignore invalid edges
	if (allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] == E_EXIST)
	{
	if (allNodeState[sampleTime*(nodeNum + 1) + tempChain->node] == CONFIRMED)
	{
	nodeUL[sampleTime*(nodeNum + 1) + i].solidEdges++;
	if (nodeUL[sampleTime*(nodeNum + 1) + i].solidEdges >= k)
	{
	allNodeState[sampleTime*(nodeNum + 1) + i] = CONFIRMED;
	}
	}
	}
	tempChain = tempChain->next;
	continue;
	}
	if (nodeUL[sampleTime*(nodeNum + 1) + i].curEdges + nodeUL[sampleTime*(nodeNum + 1) + i].remainingEdges < k)
	{
	//early stop
	allNodeState[sampleTime*(nodeNum + 1) + i] = NOTINRESULT;
	earlyStop = true;
	break;
	}
	else
	{
	if (randP() <= edges[tempChain->edgeIndex].p)
	{
	if (allNodeState[sampleTime*(nodeNum + 1) + tempChain->node] == CONFIRMED)
	{
	nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].solidEdges++;
	if (nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].solidEdges >= k)
	{
	allNodeState[sampleTime*(nodeNum + 1) + i] = CONFIRMED;
	}
	}
	// edge exist
	edgeState[tempChain->edgeIndex] = E_EXIST;
	allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] = E_EXIST;
	nodeUL[sampleTime*(nodeNum + 1) + i].curEdges++;
	nodeUL[sampleTime*(nodeNum + 1) + i].remainingEdges--;
	nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].curEdges++;
	nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].remainingEdges--;

	}
	else
	{
	edgeState[tempChain->edgeIndex] = E_NOTEXIST;
	allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] = E_NOTEXIST;
	nodeUL[sampleTime*(nodeNum + 1) + i].remainingEdges--;
	nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].remainingEdges--;
	}
	}
	tempChain = tempChain->next;
	}
	//early stop
	if (earlyStop)
	{
	tempChain = nodeC[i].next;
	while (tempChain != NULL)
	{
	if (allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] == E_TOCOMFIRM)
	{
	allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] = E_NOTEXIST;
	nodeUL[sampleTime*(nodeNum + 1) + i].remainingEdges--;
	nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].remainingEdges--;
	}
	else if (allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] == E_EXIST)
	{
	allEdgeState[sampleTime*(edgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] = E_NOTEXIST;
	nodeUL[sampleTime*(nodeNum + 1) + i].curEdges--;
	nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].curEdges--;
	}
	tempChain = tempChain->next;
	}
	}
	}

	}
	*/
	int prunedNum = 0;
	int inNum = 0;
	int outNum = 0;
	queue<int> temp2Cdt(candidateSet);
	int* upperConfirm = new int[nodeNum + 1];
	int* lowerConfirm = new int[nodeNum + 1];
	initArrayWithValue<int>(upperConfirm, nodeNum + 1, 0);
	initArrayWithValue<int>(lowerConfirm, nodeNum + 1, 0);
	while (!temp2Cdt.empty())
	{
		// change order of samlesize and node can speed up
		int i = temp2Cdt.front();
		temp2Cdt.pop();
		for (int j = 0; j < sampleSize; j++)
		{

			if (allNodeState[j*(nodeNum + 1) + i] == CONFIRMED)
			{
				upperConfirm[i]++;
				lowerConfirm[i]++;
			}
			else if (allNodeState[j*(nodeNum + 1) + i] == TOCONFIRM)
			{
				upperConfirm[i]++;
			}
		}
		if (upperConfirm[i] < int(sampleSize*threshold))
		{
			nodeState[i] = NOTINRESULT;
			candidateNum--;
			prunedNum++;
			outNum++;
			//cout << prunedNum << " out: " << i << endl;
		}
		else if (lowerConfirm[i] >= int(sampleSize*threshold))
		{
			nodeState[i] = CONFIRMED;
			candidateNum--;
			inNum++;
			prunedNum++;
			//cout << prunedNum << " in: " << i << endl;
		}
	}

	cout << "pruned num" << prunedNum << endl;;
	cout << "in num is " << inNum << endl;
	cout << "outnum is" << outNum << endl;
	//free nodeC
	cEnd = clock();
	dur2 = cEnd - cStart;
	printf("only sample neighbors  Use Time:%f\n", (dur2 / CLOCKS_PER_SEC));

	clock_t start, end;
	start = clock();

	//start state transfer algorithm
	int* activedNode = new int[nodeNum + 1];
	queue<int> newCdt;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (nodeState[i] == TOCONFIRM)
		{
			newCdt.push(i);
		}
	}
	int* minusUp = new int[nodeNum + 1];
	bool coutC = true;
	cout << sampleSize << " total samples" << endl;
	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		int curNodeStart = sampleTime*(nodeNum + 1);
		int curEdgeStart = sampleTime*(edgeNum + 1);
		initArray(minusUp, nodeNum + 1);// delete up once

										//cout << sampleTime << endl;
		if (candidateNum == 0 && coutC)
		{
			cout << sampleTime << endl;
			coutC = false;
			break;
		}
		for (int i = 0; i <= nodeNum; i++)// init active nodes
		{
			if (allNodeState[curNodeStart + i] == TOCONFIRM)//only go to nodes to confirm and not in result
			{
				activedNode[i] = 0;
			}
			else
			{
				activedNode[i] = 1;
			}
		}

		queue<int> activeCdt;
		for (int w = 0; w <= nodeNum; w++)
		{
			if (nodeState[w] == TOCONFIRM)
			{
				activeCdt.push(w);
			}
		}


		while (!activeCdt.empty() && candidateNum > 0)
		{
			int i = activeCdt.front();
			activeCdt.pop();
			if (nodeState[i] == PRUNED)
			{
				continue;
			}
			if (allNodeState[curNodeStart + i] != TOCONFIRM) // judge whether current node need to compute
			{
				continue;
			}
			nodeUL[curNodeStart + i].solidEdges = 0;//init solideEdges
			earlyStop = false;
			if (nodeUL[curNodeStart + i].curEdges + nodeUL[sampleTime*(nodeNum + 1) + i].remainingEdges < k)
			{
				earlyStop = true;
				//early stop
				if (allNodeState[curNodeStart + i] == TOCONFIRM)
				{
					if (minusUp[i] == 0)
					{
						minusUp[i] = 1;
						upperConfirm[i] --;
						if (nodeState[i] == TOCONFIRM)//check whether update candidate set
						{
							if (upperConfirm[i] < int(sampleSize*threshold))
							{
								candidateNum--;
								outNum++;
								//cout << i << " out " << endl;
								nodeState[i] = NOTINRESULT;
							}
						}
					}
				}
			}
			if (nodeUL[curNodeStart + i].remainingEdges >= 0)//there are some edges still need to be sampled
			{
				// add early stop to remaining edges
				tempChain = nodeC[i].next;
				while (tempChain != NULL)//test all neighbor edges
				{
					/* to check curEdges and remainEdges is correct or not
					int curE = 0;
					int remainE = 0;
					tempChain2 = nodeC[i].next;
					while (tempChain2 != NULL)//test all neighbor edges
					{
					if (allEdgeState[curEdgeStart + edges[tempChain2->edgeIndex].edgeIndex] == E_EXIST)
					{
					curE++;
					}
					if (allEdgeState[curEdgeStart + edges[tempChain2->edgeIndex].edgeIndex] == E_TOCOMFIRM)
					{
					remainE++;
					}
					tempChain2 = tempChain2->next;
					}*/
					if (earlyStop)
					{

						break;
					}
					if (nodeUL[curNodeStart + i].curEdges + nodeUL[curNodeStart + i].remainingEdges < k)
					{
						//early stop
						if (allNodeState[curNodeStart + i] == TOCONFIRM)
						{
							if (minusUp[i] == 0)
							{
								minusUp[i] = 1;
								upperConfirm[i] --;
								if (nodeState[i] == TOCONFIRM)//check whether update candidate set
								{
									if (upperConfirm[i] < int(sampleSize*threshold))
									{
										candidateNum--;
										outNum++;
										//cout << i << " out " << endl;
										nodeState[i] = NOTINRESULT;
									}
								}
							}
						}
						//allNodeState[curNodeStart + i] = NOTINRESULT;
						earlyStop = true;
						break;
					}
					else if (allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] != E_TOCOMFIRM)
					{
						//ignore invalid edges
						if (allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] == E_EXIST)//if edges exist and other node is confirm, this node's solid edges ++
						{
							if (allNodeState[curNodeStart + tempChain->node] == CONFIRMED)
							{
								nodeUL[curNodeStart + i].solidEdges++;
								if (nodeUL[curNodeStart + i].solidEdges >= k)
								{
									if (allNodeState[curNodeStart + i] == TOCONFIRM)
									{
										lowerConfirm[i] ++;
										if (nodeState[i] == TOCONFIRM)//check whether update candidate set
										{
											if (lowerConfirm[i] >= int(sampleSize*threshold))
											{
												candidateNum--;
												inNum++;
												//cout << i << "  in " << endl;
												nodeState[i] = CONFIRMED;
											}
										}
									}
									allNodeState[curNodeStart + i] = CONFIRMED;
								}
							}
						}
						tempChain = tempChain->next;
						continue;
					}
					else//edges state is already to confirmed
					{
						if (randP() <= edges[tempChain->edgeIndex].p)//sample new edges and it exists
						{
							if (allNodeState[curNodeStart + tempChain->node] == CONFIRMED)
							{
								nodeUL[curNodeStart + i].solidEdges++;
								if (nodeUL[curNodeStart + i].solidEdges >= k)
								{
									if (allNodeState[curNodeStart + i] == TOCONFIRM)
									{
										lowerConfirm[i] ++;
										if (nodeState[i] == TOCONFIRM)//check whether update candidate set
										{
											if (lowerConfirm[i] >= int(sampleSize*threshold))
											{
												candidateNum--;
												inNum++;
												//cout << i << "  in " << endl;
												nodeState[i] = CONFIRMED;
											}
										}
									}
									allNodeState[curNodeStart + i] = CONFIRMED;
								}
							}
							// edge exist
							edgeState[tempChain->edgeIndex] = E_EXIST;
							allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] = E_EXIST;
							nodeUL[curNodeStart + i].curEdges++;
							nodeUL[curNodeStart + i].remainingEdges--;
							nodeUL[curNodeStart + tempChain->node].curEdges++;
							nodeUL[curNodeStart + tempChain->node].remainingEdges--;

						}
						else
						{
							edgeState[tempChain->edgeIndex] = E_NOTEXIST;
							allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] = E_NOTEXIST;
							nodeUL[curNodeStart + i].remainingEdges--;
							nodeUL[curNodeStart + tempChain->node].remainingEdges--;
							if (nodeUL[curNodeStart + i].curEdges + nodeUL[curNodeStart + i].remainingEdges < k)
							{
								//early stop
								if (allNodeState[curNodeStart + i] == TOCONFIRM)
								{
									if (minusUp[i] == 0)
									{
										minusUp[i] = 1;
										upperConfirm[i] --;
										//allNodeState[curNodeStart + i] = NOTINRESULT;
										if (nodeState[i] == TOCONFIRM)//check whether update candidate set
										{
											if (upperConfirm[i] < int(sampleSize*threshold))
											{
												candidateNum--;
												outNum++;
												//cout << i << " out " << endl;
												nodeState[i] = NOTINRESULT;
											}
										}
									}
								}
								//allNodeState[curNodeStart + i] = NOTINRESULT;
								earlyStop = true;
								break;
							}
						}
					}
					tempChain = tempChain->next;
				}
				//early stop
				queue<int> earlyQ;

				if (earlyStop)
				{
					earlyQ.push(i);
					while (!earlyQ.empty())
					{
						int j = earlyQ.front();
						earlyS[curNodeStart + j] = 1;
						earlyQ.pop();
						if (allNodeState[curNodeStart + j] != TOCONFIRM)
						{
							continue;
						}
						allNodeState[curNodeStart + j] = NOTINRESULT;
						tempChain = nodeC[j].next;
						while (tempChain != NULL)//test all neighbor edges
						{
							if (allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] == E_TOCOMFIRM)
							{
								allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] = E_NOTEXIST;
								nodeUL[curNodeStart + j].remainingEdges--;
								nodeUL[curNodeStart + tempChain->node].remainingEdges--;
								if (allNodeState[curNodeStart + tempChain->node] == TOCONFIRM && nodeUL[curNodeStart + tempChain->node].remainingEdges + nodeUL[curNodeStart + tempChain->node].curEdges < k)
								{
									earlyQ.push(tempChain->node);//new node need to early terminate
									if (allNodeState[curNodeStart + tempChain->node] == TOCONFIRM)
									{
										//allNodeState[curNodeStart + tempChain->node] = NOTINRESULT;
										if (minusUp[tempChain->node] == 0)
										{
											minusUp[tempChain->node] = 1;
											upperConfirm[tempChain->node] --;
											if (nodeState[tempChain->node] == TOCONFIRM)//check whether update candidate set
											{
												if (upperConfirm[tempChain->node] < int(sampleSize*threshold))
												{
													candidateNum--;
													outNum++;
													//cout << tempChain->node << " out " << endl;
													nodeState[tempChain->node] = NOTINRESULT;
												}
											}
										}
									}
								}
							}
							else if (allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] == E_EXIST)
							{
								allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] = E_NOTEXIST;
								nodeUL[curNodeStart + j].curEdges--;
								nodeUL[curNodeStart + tempChain->node].curEdges--;
								if (allNodeState[curNodeStart + tempChain->node] == TOCONFIRM && nodeUL[curNodeStart + tempChain->node].remainingEdges + nodeUL[curNodeStart + tempChain->node].curEdges < k)
								{
									earlyQ.push(tempChain->node);
									if (allNodeState[curNodeStart + tempChain->node] == TOCONFIRM)
									{
										//allNodeState[curNodeStart + tempChain->node] = NOTINRESULT;
										if (minusUp[tempChain->node] == 0)
										{
											minusUp[tempChain->node] = 1;
											upperConfirm[tempChain->node] --;
											if (nodeState[tempChain->node] == TOCONFIRM)//check whether update candidate set
											{
												if (upperConfirm[tempChain->node] < int(sampleSize*threshold))
												{
													candidateNum--;
													outNum++;
													//cout << tempChain->node << " out " << endl;
													nodeState[tempChain->node] = NOTINRESULT;
												}
											}
										}
									}
								}
							}
							tempChain = tempChain->next;
						}
					}
				}
				// all candidat not confirmed at last will be confirmed

			}
			else//all the edges have been sampled for this node
			{
				//cout << i << endl;
			}
			//add active nodes
			if (nodeUL[curNodeStart + i].remainingEdges != 0)
			{
				cout << "not sample all" << endl;
			} // check whether sample all the edges
			if (allNodeState[curNodeStart + i] == TOCONFIRM)
			{
				tempChain = nodeC[i].next;
				while (tempChain != NULL)
				{

					if (allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] == E_EXIST)
					{
						if (activedNode[tempChain->node] == 0 && allNodeState[curNodeStart + tempChain->node] == TOCONFIRM)
						{
							activeCdt.push(tempChain->node);
							activedNode[tempChain->node] = 2;
						}
					}
					tempChain = tempChain->next;
				}
			}
		}
		//check whether some nodes confirmed after this sample round

		queue<int> temp4Cdt(newCdt);
		while (!temp4Cdt.empty())//record all the noded which has been visited
		{
			int i = temp4Cdt.front();
			temp4Cdt.pop();
			if (allNodeState[curNodeStart + i] == TOCONFIRM && nodeState[i] == TOCONFIRM)
			{

				/*if (nodeUL[curNodeStart + i].curEdges < k)
				{
				cout << i << " degree < k" << endl;
				upperConfirm[i] --;
				allNodeState[curNodeStart + i] = NOTINRESULT;
				if (nodeState[i] == TOCONFIRM)//check whether update candidate set
				{
				if (upperConfirm[i] < int(sampleSize*threshold))
				{
				candidateNum--;
				outNum++;
				//cout << i << " out " << endl;
				nodeState[i] = NOTINRESULT;
				}
				}
				}*/ //test whether degree is small than k
				/*tempChain = nodeC[i].next;
				while (tempChain != NULL)
				{
				if (allEdgeState[curEdgeStart + edges[tempChain->edgeIndex].edgeIndex] == E_EXIST && allNodeState[curNodeStart + tempChain->node] == TOCONFIRM &&nodeUL[curNodeStart + tempChain->node].curEdges != 0 && nodeUL[curNodeStart + tempChain->node].curEdges < k)
				{
				cout << tempChain->node << " degree < k  who is a neib of " << i << endl;
				}
				tempChain = tempChain->next;
				}*/ //test whether neibors degree is less than k
				//cout << i << endl;
				allNodeState[curNodeStart + i] = CONFIRMED;
				lowerConfirm[i] ++;
				if (nodeState[i] == TOCONFIRM)//check whether update candidate set
				{
					if (lowerConfirm[i] >= int(sampleSize*threshold))
					{
						candidateNum--;
						inNum++;
						//cout << i << " end of task in " << endl;
						nodeState[i] = CONFIRMED;
					}
				}
			}
		}
	}
	end = clock();
	double dur = end - start;
	printf("active stage  Use Time:%f\n", (dur / CLOCKS_PER_SEC));


	cout << "in num is " << inNum << endl;
	cout << "outnum is" << outNum << endl;
	// add result
	for (int i = 0; i <= nodeNum; i++)
	{
		if (nodeState[i] == CONFIRMED)
		{
			result[i] = 1;
		}
		else
		{
			result[i] = 0;
		}
	}


	for (int i = 0; i <= nodeNum; i++)
	{

		tempChain = nodeC[i].next;
		while (tempChain != NULL)
		{
			tempChainPre = tempChain->next;
			delete tempChain;
			tempChain = tempChainPre;
		}
	}


	delete[] edgeState;
	delete[] edgeP;
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	delete[] nodeC;
	return;
}




void newModelDecompositionEarlyStopWithoutEdgeOrderWithNodeState
(orderEdge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden, int* nodeState, short* allEdgeState, int* allNodeState, upLowNum* nodeUL, int totalEdgeNum)
{
	int sampleSize = calcSampleTimes(delta, epsilon, noden);

	cout << "new mode sample size" << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	bool earlyStop = false;
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;


	}


	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int i = 0; i <= nodeNum; i++)
		{

			earlyStop = false;
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
					//early stop
					earlyStop = true;
					break;
				}
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = E_EXIST;
						allEdgeState[sampleTime*(totalEdgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] = E_EXIST;
						nodeUL[sampleTime*(nodeNum + 1) + i].curEdges++;
						nodeUL[sampleTime*(nodeNum + 1) + i].remainingEdges--;
						nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].remainingEdges--;
						nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].curEdges++;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;

						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = E_NOTEXIST;
						allEdgeState[sampleTime*(totalEdgeNum + 1) + edges[tempChain->edgeIndex].edgeIndex] = E_NOTEXIST;
						nodeUL[sampleTime*(nodeNum + 1) + i].remainingEdges--;
						nodeUL[sampleTime*(nodeNum + 1) + tempChain->node].remainingEdges--;

						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
			//early stop
			if (earlyStop)
			{
				tempChain = nodeC[i].next;
				while (tempChain != NULL)
				{
					if (edgeState[tempChain->edgeIndex] == -1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
					else if (edgeState[tempChain->edgeIndex] == 1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
					}
					tempChain = tempChain->next;

				}
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeStateWithAllNodeState(edges, edgeState, edgeNum, nodeNum, sampleResult, allNodeState, sampleTime);

	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	//delete[] components;

	//free nodeC

	for (int i = 0; i <= NODE_COUNT; i++)
	{
		tempChain = nodeC[i].next;
		while (tempChain != NULL)
		{
			tempChainPre = tempChain->next;
			delete tempChain;
			tempChain = tempChainPre;
		}
	}


	delete[] edgeState;
	delete[] edgeP;
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	delete[] nodeC;
	return;
}


void newModelDecompositionEarlyStopWithoutEdgeOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden)
{
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "new mode sample size" << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	bool earlyStop = false;
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;


	}

	//cacluate components
	/*
	int* components = new int[nodeNum + 1];
	cout << 0 << " " << degrees[0] << endl;
	int no_compoents = findOutConnectedCompoent(components,nodeNum,edges,edgeNum,degrees,nodeC);

	cout << "number of compoents" << no_compoents << endl;
	*/
	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}

		for (int j = kStartIndex[k - 1] + 1; j <= nodeNum; j++)
		{
			int i = resortNode[j];
			earlyStop = false;
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
					//early stop
					earlyStop = true;
					break;
				}
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
			//early stop
			if (earlyStop)
			{
				tempChain = nodeC[i].next;
				while (tempChain != NULL)
				{
					if (edgeState[tempChain->edgeIndex] == -1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
					else if (edgeState[tempChain->edgeIndex] == 1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
					}
					tempChain = tempChain->next;

				}
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	//delete[] components;

	//free nodeC

	for (int i = 0; i <= NODE_COUNT; i++)
	{
		tempChain = nodeC[i].next;
		while (tempChain != NULL)
		{
			tempChainPre = tempChain->next;
			delete tempChain;
			tempChain = tempChainPre;
		}
	}


	delete[] edgeState;
	delete[] edgeP;
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	delete[] nodeC;
	return;
}

void newModelDecompositionDoubleEarlyStopWithoutEdgeOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden, int no_components, int* components, int* nodeState, double threshold)
{


	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	cout << "new mode sample size" << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	bool earlyStop = false;
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	int* componentEdgeState = new int[edgeNum + 1];
	//init componentEdgeState
	for (int i = 0; i < edgeNum; i++)
	{
		componentEdgeState[i] = -1;// available at first
	}


	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;


	}

	//cacluate components
	/*
	int* components = new int[nodeNum + 1];
	cout << 0 << " " << degrees[0] << endl;
	int no_compoents = findOutConnectedCompoent(components,nodeNum,edges,edgeNum,degrees,nodeC);

	cout << "number of compoents" << no_compoents << endl;
	*/
	int reducenum = 0;
	double chechSchedule = 0.1;
	int checkTime = int(sampleSize*chechSchedule);
	no_components = findOutConnectedCompoent(components, nodeNum, edges, edgeNum, degrees, nodeC);
	cout << no_components << " comps in total" << endl;
	int* componentState = new int[no_components + 1];
	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		if (checkTime == sampleTime || sampleTime == 0)
		{
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeState[i] != -1)
				{
					continue;
				}
				if (sampleResult[i] >= ceil(sampleSize*threshold))
				{
					nodeState[i] = 1;//already in results
									 //cout << i <<" exists " << endl;
				}
				else if ((sampleResult[i] + sampleSize - sampleTime) < ceil(sampleSize*threshold))
				{
					nodeState[i] = 0;//already not in results
									 //cout << i <<" not exists " << endl;
				}
			}
			chechSchedule += 0.1;
			checkTime = int(sampleSize*chechSchedule);
			initArray(componentState, no_components + 1);
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeState[i] == -1)
				{
					componentState[components[i]] = 1;
				}
				else
				{
					//componentState[components[i]] = 0;
				}
			}
			for (int i = 0; i < edgeNum; i++)
			{
				if (componentEdgeState[i] != -1)
				{
					continue;
				}
				if (componentState[components[edges[i].x]] + componentState[components[edges[i].y]] == 0)
				{
					componentEdgeState[i] = 0;
					degrees[edges[i].x] --;
					degrees[edges[i].y] --;
					reducenum++;
				}
				else if (componentState[components[edges[i].x]] + componentState[components[edges[i].y]] == 1)
				{
					cout << "component state error" << endl;
				}
			}
			cout << reducenum << " edges reduced by result candidate" << endl;
		}

		//cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = componentEdgeState[i];//means to be determined
		}

		for (int j = kStartIndex[k - 1] + 1; j <= nodeNum; j++)
		{
			int i = resortNode[j];
			earlyStop = false;
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				if (nodeC[i].curEdges + nodeC[i].remainingEdges < k)
				{
					//early stop
					earlyStop = true;
					break;
				}
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
			//early stop
			if (earlyStop)
			{
				tempChain = nodeC[i].next;
				while (tempChain != NULL)
				{
					if (edgeState[tempChain->edgeIndex] == -1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
					else if (edgeState[tempChain->edgeIndex] == 1)
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
					}
					tempChain = tempChain->next;

				}
			}
		}

		bool updated = true;
		while (updated)
		{
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (nodeC[i].remainingEdges != 0)
				{
					cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
				}
				if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
				{
					tempChain = nodeC[i].next;
					while (tempChain != NULL)
					{
						if (edgeState[tempChain->edgeIndex] != 1)
						{
							tempChain = tempChain->next;
							continue;
						}
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].curEdges--;
						nodeC[tempChain->node].curEdges--;
						updated = true;
						tempChain = tempChain->next;
					}
				}
			}
		}
		addSampleResultsEdgeState(edges, edgeState, edgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		if (sampleResult[i] >= threshold)
		{
			nodeState[i] = 1;
		}
		else if (nodeState[i] == -1)
		{
			nodeState[i] = 0;
		}
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	//delete[] components;

	//free nodeC

	for (int i = 0; i <= NODE_COUNT; i++)
	{
		tempChain = nodeC[i].next;
		while (tempChain != NULL)
		{
			tempChainPre = tempChain->next;
			delete tempChain;
			tempChain = tempChainPre;
		}
	}


	delete[] componentState;
	delete[] componentEdgeState;
	delete[] edgeState;
	delete[] edgeP;
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	delete[] nodeC;
	return;
}


void newModelDecompositionEarlyStopWithoutEdgeOrderExpectedValue(Edge* edges, int nodeNum, int edgeNum, int maxdegree, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden)
{
	//use tempSampleResult like sampleResult[k][nodeIndex]
	double* tempSampleResult = new double[(maxdegree + 1)*(nodeNum + 1)];
	initDoubleArray(tempSampleResult, (maxdegree + 1)*(nodeNum + 1));
	int sampleSize = calcSampleTimes(delta, epsilon, noden);
	int k = 1;
	cout << "new mode sample size" << sampleSize << endl;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	int maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);

	bool earlyStop = false;
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	Edge* tempEdge = new Edge[maxDegree];
	earlyStopChainHead* nodeC = new earlyStopChainHead[NODE_COUNT + 1];
	int* edgeState = new int[edgeNum + 1];
	double* edgeP = new double[edgeNum + 1];
	initArray(edgeState, edgeNum + 1);
	initDoubleArray(edgeP, edgeNum + 1);
	earlyStopChain* tempChain;
	earlyStopChain* tempChainPre;
	for (int i = 0; i < edgeNum; i++)
	{

		earlyStopChain* temp0 = new earlyStopChain;
		earlyStopChain* temp1 = new earlyStopChain;
		//earlyStopChain* temp2 = new earlyStopChain;
		//from small to large insert

		//cout << i << endl;
		temp0->node = edges[i].y;
		edgeP[i] = edges[i].p;
		temp0->edgeIndex = i;
		temp1->node = edges[i].x;
		temp1->edgeIndex = i;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;


	}

	//cacluate components
	/*
	int* components = new int[nodeNum + 1];
	cout << 0 << " " << degrees[0] << endl;
	int no_compoents = findOutConnectedCompoent(components,nodeNum,edges,edgeNum,degrees,nodeC);

	cout << "number of compoents" << no_compoents << endl;
	*/
	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		cout << sampleTime << endl;
		for (int i = 0; i <= nodeNum; i++)
		{
			nodeC[i].remainingEdges = degrees[i];
			nodeC[i].curEdges = 0;
		}
		for (int i = 0; i < edgeNum; i++)
		{
			edgeState[i] = -1;//means to be determined
		}


		for (int i = 0; i <= nodeNum; i++)
		{
			earlyStop = false;
			tempChain = nodeC[i].next;
			while (tempChain != NULL)
			{
				if (edgeState[tempChain->edgeIndex] != -1)
				{
					//ignore invalid edges
					tempChain = tempChain->next;
					continue;
				}
				else
				{
					if (randP() <= edges[tempChain->edgeIndex].p)
					{
						// edge exist
						edgeState[tempChain->edgeIndex] = 1;
						nodeC[i].curEdges++;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].curEdges++;
						nodeC[tempChain->node].remainingEdges--;

					}
					else
					{
						edgeState[tempChain->edgeIndex] = 0;
						nodeC[i].remainingEdges--;
						nodeC[tempChain->node].remainingEdges--;
					}
				}
				tempChain = tempChain->next;
			}
		}

		bool updated = true;

		//cout << maxDegree << endl;

		for (k = 1; k <= maxDegree; k++)
		{
			//cout << k << endl;
			updated = true;
			while (updated)
			{
				updated = false;
				for (int i = 0; i <= nodeNum; i++)
				{
					if (nodeC[i].remainingEdges != 0)
					{
						cout << "not 0 remaining edges" << nodeC[i].remainingEdges << endl;
					}
					if (nodeC[i].curEdges < k && nodeC[i].curEdges != 0)
					{
						tempChain = nodeC[i].next;
						while (tempChain != NULL)
						{
							if (edgeState[tempChain->edgeIndex] != 1)
							{
								tempChain = tempChain->next;
								continue;
							}
							edgeState[tempChain->edgeIndex] = 0;
							nodeC[i].curEdges--;
							nodeC[tempChain->node].curEdges--;
							updated = true;
							tempChain = tempChain->next;
						}
					}
				}
			}
			addSampleResultsEdgeStateExpectedValue(edges, edgeState, edgeNum, nodeNum, tempSampleResult, k, maxdegree);
		}
	}
	double tempResult = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		for (k = 1; k < maxdegree; k++)
		{
			tempResult += (tempSampleResult[k*(nodeNum + 1) + i] - tempSampleResult[(k + 1)*(nodeNum + 1) + i]) / double(sampleSize) * k;
		}
		sampleResult[i] = tempResult;
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	//delete[] components;
	delete[] nodePs;
	delete[] tempEdge;
	delete[] degrees;
	return;
}


void newModelDecomposition(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult)
{
	int sampleSize = 1000;
	//int* sampleResult = new int[nodeNum+1];
	initDoubleArray(sampleResult, nodeNum + 1);
	int cerEdgeNum = 0;
	int* degrees = new int[nodeNum + 1];
	initArray(degrees, nodeNum + 1);
	Edge* cerEdges = new Edge[edgeNum + 1];
	initPariArray(cerEdges, edgeNum + 1);
	for (int sampleTime = 0; sampleTime < sampleSize; sampleTime++)
	{
		cout << sampleTime << endl;
		cerEdgeNum = 0;
		int newEdgeNum = 0;
		//int maxDegree = findMAxDegree(edges,nodeNum,cerEdgeNum,degrees);
		for (int i = 0; i < edgeNum; i++)
		{
			if (randP() <= edges[i].p)
			{
				cerEdges[cerEdgeNum].x = edges[i].x;
				cerEdges[cerEdgeNum].y = edges[i].y;
				cerEdges[cerEdgeNum++].p = 1;
			}

		}
		int maxDegree = findMAxDegree(cerEdges, nodeNum, cerEdgeNum, degrees);
		while (newEdgeNum != cerEdgeNum)
		{
			newEdgeNum = cerEdgeNum;
			for (int j = 1; j <= nodeNum; j++)
			{
				if (degrees[j] < k && degrees[j] != 0)
				{
					//delete all the egdge which contains node j
					for (int w = 0; w < cerEdgeNum;)
					{
						if (cerEdges[w].x == j || cerEdges[w].y == j)
						{
							degrees[cerEdges[w].x] --;
							degrees[cerEdges[w].y] --;
							cerEdges[w].x = cerEdges[cerEdgeNum - 1].x;
							cerEdges[w].y = cerEdges[cerEdgeNum - 1].y;
							cerEdges[w].p = cerEdges[cerEdgeNum - 1].p;
							cerEdgeNum--;
							continue;
						}
						w++;
					}
					//maxDegree = findMAxDegree(cerEdges, nodeNum, cerEdgeNum, degrees);
				}
			}
		}
		addSampleResults(cerEdges, cerEdgeNum, nodeNum, sampleResult);
	}
	for (int i = 1; i <= nodeNum; i++)
	{
		sampleResult[i] = sampleResult[i] / double(sampleSize);
		//if (sampleResult[i] > 0.001)
		//{
		//cout << i << ":||" << sampleResult[i] << endl;
		//}
	}

	//
	delete[] degrees;
	delete[] cerEdges;
	return;
}

int findMAxDegree(orderEdge* edges, int nodeNum, int edgeNum, int* degrees)
{
	initArray(degrees, nodeNum + 1);
	for (int i = 0; i < edgeNum; i++)
	{
		degrees[edges[i].x]++;
		degrees[edges[i].y]++;
	}
	int tempMax = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (degrees[i] > tempMax)
		{
			tempMax = degrees[i];
		}
	}
	return tempMax;
}


int findMAxDegree(Edge* edges, int nodeNum, int edgeNum, int* degrees)
{
	initArray(degrees, nodeNum + 1);
	for (int i = 0; i < edgeNum; i++)
	{
		degrees[edges[i].x]++;
		degrees[edges[i].y]++;
	}
	int tempMax = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (degrees[i] > tempMax)
		{
			tempMax = degrees[i];
		}
	}
	return tempMax;
}



void clacInitialPro(int node, int nodeDegree, Edge* edges, int maxDegree, int edgeNum, double* initialPro, int nodeNum)
{
	int currentIndex = 0;
	double* pEdge = new double[nodeDegree + 2];
	double* X = new double[(nodeDegree + 1)*(nodeDegree + 2)];
	for (int i = 0; i < (nodeDegree + 1)*(nodeDegree + 2); i++)
	{
		X[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x == node || edges[i].y == node)
		{
			pEdge[currentIndex++] = edges[i].p;
			//cout << "pEdge" << currentIndex << pEdge[currentIndex-1] << endl;
		}
	}
	X[0 * (nodeDegree + 2) + 1] = 1;// X[0][0] = 1; 
	for (int i = 0; i <= nodeDegree; i++)
	{
		X[i*(nodeDegree + 2) + 0] = 0;//X[h][-1] = 0;
	}
	for (int h = 1; h <= nodeDegree; h++)
	{
		for (int j = 0; j <= h; j++)
		{
			X[h*(nodeDegree + 2) + j + 1] = pEdge[h - 1] * X[(h - 1)*(nodeDegree + 2) + j] + (1 - pEdge[h - 1])*X[(h - 1)*(nodeDegree + 2) + j + 1];
		}
	}
	if (currentIndex != nodeDegree)
	{
		cout << "clacNodeP error: currentIndex != nodeDegree" << endl;
	}
	double result = 0;

	for (int j = 0; j <= nodeDegree; j++)
	{
		initialPro[node*(maxDegree + 1) + j] = X[nodeDegree*(nodeDegree + 2) + j + 1];
	}
	if (result < 0 || result > 1.001)
	{
		cout << "clacNodeP error || " << result << endl;
	}
	delete[] pEdge;
	delete[] X;
	//return result;
}




double clacNodeP(int node, int nodeDegree, Edge* edges, int maxDegree, int edgeNum, int k)
{
	int currentIndex = 0;
	double* pEdge = new double[nodeDegree + 2];
	double* X = new double[(nodeDegree + 1)*(nodeDegree + 2)];
	for (int i = 0; i < (nodeDegree + 1)*(nodeDegree + 2); i++)
	{
		X[i] = 0;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		if (edges[i].x == node || edges[i].y == node)
		{
			pEdge[currentIndex++] = edges[i].p;
			//cout << "pEdge" << currentIndex << pEdge[currentIndex-1] << endl;
		}
	}
	X[0 * (nodeDegree + 2) + 1] = 1;// X[0][0] = 1; 
	for (int i = 0; i <= nodeDegree; i++)
	{
		X[i*(nodeDegree + 2) + 0] = 0;//X[h][-1] = 0;
	}
	for (int h = 1; h <= nodeDegree; h++)
	{
		for (int j = 0; j <= h; j++)
		{
			X[h*(nodeDegree + 2) + j + 1] = pEdge[h - 1] * X[(h - 1)*(nodeDegree + 2) + j] + (1 - pEdge[h - 1])*X[(h - 1)*(nodeDegree + 2) + j + 1];
		}
	}
	if (currentIndex != nodeDegree)
	{
		cout << "clacNodeP error: currentIndex != nodeDegree" << endl;
	}
	double result = 0;
	for (int i = k; i <= nodeDegree; i++)
	{
		//cout << "X" << result << endl;
		//if (node == 666)
		//{
		//	cout << "X" << X[nodeDegree*(nodeDegree + 2) + i + 1] << endl;
		//}
		result += X[nodeDegree*(nodeDegree + 2) + i + 1];
	}
	if (result < 0 || result > 1.001)
	{
		cout << "clacNodeP error ||  " << result << endl;
	}
	delete[] pEdge;
	delete[] X;
	return result;
}

void sampleKdd(int edgeNum, Edge* edges, int maxDegree, int nodeNum, int k, int degrees[], int resultNode[])
{
	int newEdgeNum;
	Edge *kddEdges = new Edge[EDGE_COUNT + 1];
	int* result = new int[(NODE_COUNT + 1)*(maxDegree + 1)];
	int sampleTime = 10;
	double threshold = 0;
	int* newDegrees = new int[NODE_COUNT + 1];
	double* pNode = new double[maxDegree + 1];
	initDoubleArray(pNode, maxDegree + 1);
	initPariArray(kddEdges, EDGE_COUNT + 1);
	initArray(resultNode, NODE_COUNT + 1);
	initArray(result, (NODE_COUNT + 1)*(maxDegree + 1));
	for (int i = 0; i < sampleTime; i++)
	{
		cout << i << " || kddsample" << endl;
		threshold = randP();
		newEdgeNum = edgeNum;
		for (int j = 0; j < edgeNum; j++)
		{
			kddEdges[j].x = edges[j].x;
			kddEdges[j].y = edges[j].y;
			kddEdges[j].p = edges[j].p;
		}
		for (int k = 0; k <= NODE_COUNT; k++)
		{
			newDegrees[k] = degrees[k];
		}
		kddCoreDecompositionExpected(newEdgeNum, kddEdges, maxDegree, threshold, nodeNum, newDegrees, result);

	}
	// calculate the result nodes
	for (int i = 1; i <= NODE_COUNT; i++)
	{
		initDoubleArray(pNode, maxDegree + 1);
		result[i*(maxDegree + 1)] = sampleTime;
		for (int j = 0; j < maxDegree; j++)
		{
			pNode[j] = (result[(maxDegree + 1)*i + j] - result[(maxDegree + 1)*i + j + 1]) / double(sampleTime);
		}
		pNode[maxDegree] = result[(maxDegree + 1)*i + maxDegree] / double(sampleTime);
		double expectedNode = 0;
		for (int l = 1; l <= maxDegree; l++)
		{
			expectedNode += l * pNode[l];
		}
		if (expectedNode >= k)
		{
			resultNode[i] = 1;
		}
		else {
			resultNode[i] = 0;
		}
	}
	delete[] pNode;
	delete[] newDegrees;
	delete[] kddEdges;
	delete[] result;

}


// the verify version of kdd expected
void kddCoreDecompositionExpectedOrigin(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int degrees[], int result[])
{

	int* tempResult = new int[NODE_COUNT + 1];
	initArray(tempResult, NODE_COUNT + 1);
	double* X = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	for (int k = 1; k <= maxDegree; k++)
	{
		newEdgeNum = 0;
		while (edgeNum != newEdgeNum && edgeNum != 0)
		{
			newEdgeNum = edgeNum;
			for (int i = 1; i <= nodeNum; i++)
			{
				if (degrees[i] == 0)
				{
					continue;
				}
				double temp = clacNodeP(i, degrees[i], edges, maxDegree, edgeNum, k);
				if (temp < threshold && degrees[i] != 0)
				{
					//delete all the x
					for (int j = 0; j < edgeNum;)
					{
						if (edges[j].x == i || edges[j].y == i)
						{
							degrees[edges[j].x]--;
							degrees[edges[j].y]--;
							edges[j].x = edges[edgeNum - 1].x;
							edges[j].y = edges[edgeNum - 1].y;
							edges[j].p = edges[edgeNum - 1].p;
							edgeNum--;
							continue;
						}
						j++;
					}
				}
			}
			//clacNodeP(X,maxDegree);
		}
		// add the result nodes
		initArray(tempResult, NODE_COUNT + 1);
		for (int edgeIndex = 0; edgeIndex < edgeNum; edgeIndex++)
		{
			tempResult[edges[edgeIndex].x] = 1;
			tempResult[edges[edgeIndex].y] = 1;
		}
		if (edgeNum != 0)
		{
			for (int w = 1; w <= NODE_COUNT; w++)
			{
				result[(w)*(maxDegree + 1) + k] += tempResult[w];
			}
		}
	}
	delete[] tempResult;
	delete[] X;
	return;

}


void kddCoreDecompositionExpected(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int degrees[], int result[])
{
	int* tempResult = new int[NODE_COUNT + 1];
	initArray(tempResult, NODE_COUNT + 1);
	double* initialPro = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	//calculate the initial probability distribution
	for (int i = 1; i <= nodeNum; i++)
	{
		clacInitialPro(i, degrees[i], edges, maxDegree, edgeNum, initialPro, nodeNum);
	}

	for (int k = 1; k <= maxDegree; k++)
	{
		newEdgeNum = 0;
		while (edgeNum != newEdgeNum && edgeNum != 0)
		{
			newEdgeNum = edgeNum;
			for (int i = 1; i <= nodeNum; i++)
			{
				double temp = 0;
				//calc temp
				for (int h = k; h <= degrees[i]; h++)
				{
					temp += initialPro[i*(maxDegree + 1) + h];
				}
				if (temp < threshold && degrees[i] != 0)
				{
					//delete all the x
					for (int j = 0; j < edgeNum;)
					{
						if (edges[j].x == i || edges[j].y == i)
						{
							//update initialPro
							initialPro[edges[j].x*(maxDegree + 1)] = 1 / (1 - edges[j].p)*initialPro[edges[j].x*(maxDegree + 1)];
							initialPro[edges[j].y*(maxDegree + 1)] = 1 / (1 - edges[j].p)*initialPro[edges[j].y*(maxDegree + 1)];

							for (int h = 1; h <= degrees[edges[j].x]; h++)
							{
								initialPro[edges[j].x*(maxDegree + 1) + h] = 1 / (1 - edges[j].p) *(initialPro[edges[j].x*(maxDegree + 1) + h] - initialPro[edges[j].x*(maxDegree + 1) + h - 1]);

							}
							for (int h = 1; h <= degrees[edges[j].y]; h++)
							{
								initialPro[edges[j].y*(maxDegree + 1) + h] = 1 / (1 - edges[j].p) *(initialPro[edges[j].y*(maxDegree + 1) + h] - initialPro[edges[j].y*(maxDegree + 1) + h - 1]);

							}
							degrees[edges[j].x]--;
							degrees[edges[j].y]--;
							edges[j].x = edges[edgeNum - 1].x;
							edges[j].y = edges[edgeNum - 1].y;
							edges[j].p = edges[edgeNum - 1].p;
							edgeNum--;
							continue;
						}
						j++;
					}
				}
			}
			//clacNodeP(X,maxDegree);
		}
		// add the result nodes
		initArray(tempResult, NODE_COUNT + 1);
		for (int edgeIndex = 0; edgeIndex < edgeNum; edgeIndex++)
		{
			tempResult[edges[edgeIndex].x] = 1;
			tempResult[edges[edgeIndex].y] = 1;
		}
		if (edgeNum != 0)
		{
			for (int w = 1; w <= NODE_COUNT; w++)
			{
				result[(w)*(maxDegree + 1) + k] += tempResult[w];
			}
		}
	}
	delete[] tempResult;
	delete[] initialPro;
	return;

}

void kddCoreDecomposition(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[])
{
	int* tempResult = new int[NODE_COUNT + 1];
	initArray(tempResult, NODE_COUNT + 1);
	double* initialPro = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	//calculate the initial probability distribution
	for (int i = 1; i <= nodeNum; i++)
	{
		clacInitialPro(i, degrees[i], edges, maxDegree, edgeNum, initialPro, nodeNum);
	}

	newEdgeNum = 0;
	while (edgeNum != newEdgeNum && edgeNum != 0)
	{
		newEdgeNum = edgeNum;
		for (int i = 1; i <= nodeNum; i++)
		{
			if (degrees[i] == 0)
			{
				continue;
			}
			double temp = 0;
			//calc temp
			for (int h = k; h <= degrees[i]; h++)
			{
				temp += initialPro[i*(maxDegree + 1) + h];
			}


			double temp2 = clacNodeP(i, degrees[i], edges, maxDegree, edgeNum, k);
			if (abs(temp - temp2) >= 0.0001)
			{
				cout << "not the same" << endl;
			}
			if (temp < threshold && degrees[i] != 0)
			{
				//delete all the x
				for (int j = 0; j < edgeNum;)
				{
					if (edges[j].x == i || edges[j].y == i)
					{
						//update initialPro
						if (edges[j].p >= 1 - PRECISIOM)
						{

							for (int h = 0; h < degrees[edges[j].x]; h++)
							{
								initialPro[edges[j].x*(maxDegree + 1) + h] = initialPro[edges[j].x*(maxDegree + 1) + h + 1];
							}
							for (int h = 0; h < degrees[edges[j].y]; h++)
							{
								initialPro[edges[j].y*(maxDegree + 1) + h] = initialPro[edges[j].y*(maxDegree + 1) + h + 1];
							}
						}
						else
						{
							double temp3, temp4;
							temp3 = abs(initialPro[edges[j].x*(maxDegree + 1)] / (1.0 - edges[j].p));
							temp4 = abs(initialPro[edges[j].y*(maxDegree + 1)] / (1.0 - edges[j].p));
							if (temp3 > 1.0001 || temp4 > 1.0001 || temp4 < 0 || temp3 < 0)
							{
								cout << "update error 0" << endl;
							}
							temp3 = (temp3 > PRECISIOM ? temp3 : 0);
							temp4 = (temp4 > PRECISIOM ? temp4 : 0);
							initialPro[edges[j].x*(maxDegree + 1)] = temp3;
							initialPro[edges[j].y*(maxDegree + 1)] = temp4;
							for (int h = 1; h < degrees[edges[j].x]; h++)
							{
								temp3 = abs((initialPro[edges[j].x*(maxDegree + 1) + h] - edges[j].p*initialPro[edges[j].x*(maxDegree + 1) + h - 1]) / (1.0 - edges[j].p));
								if (temp3 > 1.0001 || temp3 < 0)
								{
									cout << "update error x " << endl;
								}
								temp3 = (temp3 > PRECISIOM ? temp3 : 0);
								initialPro[edges[j].x*(maxDegree + 1) + h] = temp3;
							}
							for (int h = 1; h < degrees[edges[j].y]; h++)
							{
								temp4 = abs((initialPro[edges[j].y*(maxDegree + 1) + h] - edges[j].p*initialPro[edges[j].y*(maxDegree + 1) + h - 1]) / (1.0 - edges[j].p));
								if (temp4 > 1.0001 || temp4 < 0)
								{
									cout << "update error y" << endl;
								}
								temp4 = (temp4 > PRECISIOM ? temp4 : 0);
								initialPro[edges[j].y*(maxDegree + 1) + h] = temp4;
							}
						}
						degrees[edges[j].x]--;
						degrees[edges[j].y]--;
						edges[j].x = edges[edgeNum - 1].x;
						edges[j].y = edges[edgeNum - 1].y;
						edges[j].p = edges[edgeNum - 1].p;
						edgeNum--;
						continue;
					}
					j++;
				}
			}
		}
		//clacNodeP(X,maxDegree);
	}
	delete[] tempResult;
	delete[] initialPro;
	return;

}


void kddCoreDecompositionOrigin(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[])
{

	double* X = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	while (edgeNum != newEdgeNum && edgeNum != 0)
	{
		//cout << edgeNum << endl;
		newEdgeNum = edgeNum;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] == 0)
			{
				continue;
			}


			////

			double temp = clacNodeP(i, degrees[i], edges, maxDegree, edgeNum, k);
			if (temp < threshold && degrees[i] != 0)
			{

				for (int j = 0; j < edgeNum;)
				{
					if (edges[j].x == i || edges[j].y == i)
					{
						degrees[edges[j].x]--;
						degrees[edges[j].y]--;
						edges[j].x = edges[edgeNum - 1].x;
						edges[j].y = edges[edgeNum - 1].y;
						edges[j].p = edges[edgeNum - 1].p;
						edgeNum--;
						continue;
					}
					j++;
				}
			}
		}
		//clacNodeP(X,maxDegree);
	}
	delete[] X;
	return;

}


int kddCoreDecompositionOriginSpeedUpMarkovInequalityRemoveEdges(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[])
{
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	//int edgeNum = inputEdgeNum;
	Edge* tempEdge = new Edge[maxDegree];
	Edge* temp2Edges = new Edge[edgeNum + 1];
	nodeChain* nodeC = new nodeChain[NODE_COUNT + 1];
	bool* edgeState = new bool[edgeNum + 1];
	for (int i = 0; i < edgeNum; i++)
	{
		edgeState[i] = 1;
		temp2Edges[i].x = edges[i].x;
		temp2Edges[i].y = edges[i].y;
		temp2Edges[i].p = edges[i].p;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		nodeChain* temp0 = new nodeChain;
		nodeChain* temp1 = new nodeChain;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp0->node = edges[i].y;
		temp0->p = edges[i].p;
		temp0->edgeNum = i;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
		temp1->node = edges[i].x;
		temp1->p = edges[i].p;
		temp1->edgeNum = i;
	}
	double* X = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	while (edgeNum != newEdgeNum && edgeNum != 0)//there is no "edgeNum --", hence there while loop only run once.
	{
		//cout << edgeNum << endl;
		newEdgeNum = edgeNum;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] == 0)
			{
				nodePs[i] = 0;
				continue;
			}


			////
			nodeChain* tempNodeChain = nodeC[i].next;
			int edgeI = 0;
			while (tempNodeChain != NULL)
			{
				tempEdge[edgeI].x = i;
				tempEdge[edgeI].y = tempNodeChain->node;
				tempEdge[edgeI].p = tempNodeChain->p;
				edgeI++;
				tempNodeChain = tempNodeChain->next;
			}

			double temp = clacNodeP(i, degrees[i], tempEdge, maxDegree, degrees[i], k);
			nodePs[i] = temp;
			/*if (temp < threshold && degrees[i] != 0)
			{
			//delete all the x
			degrees[i] = 0;
			nodeChain* tempNodeC = &nodeC[i];
			nodeChain* tempNodeNext = tempNodeC->next;
			while (tempNodeNext != NULL)
			{
			//edgeNum--;
			degrees[tempNodeNext->node]--;
			//delete repeat edges
			nodeChain* tempNodeD = &nodeC[tempNodeNext->node];
			nodeChain* tempNodeDNext = tempNodeD->next;
			while (tempNodeDNext != NULL)
			{
			if (tempNodeDNext->node == i)
			{
			tempNodeD->next = tempNodeDNext->next;
			delete tempNodeDNext;
			break;
			}
			tempNodeD = tempNodeDNext;
			tempNodeDNext = tempNodeDNext->next;
			}

			tempNodeC = tempNodeNext;
			tempNodeNext = tempNodeNext->next;
			edges[tempNodeC->edgeNum].x = -1;
			edges[tempNodeC->edgeNum].y = -1;

			delete tempNodeC;
			}
			//delete tempNodeC;
			nodeC[i].next = NULL;
			/*for (int j = 0; j < edgeNum;)
			{
			if (edges[j].x == i || edges[j].y == i)
			{
			degrees[edges[j].x]--;
			degrees[edges[j].y]--;
			edges[j].x = edges[edgeNum - 1].x;
			edges[j].y = edges[edgeNum - 1].y;
			edges[j].p = edges[edgeNum - 1].p;
			edgeNum--;
			continue;
			}
			j++;
			}
			}*/

		}
		//have calced all the nodePs
		bool updated = true;
		int updatedNum = 0;
		int newUpdatedNum = 0;
		afternum = 0;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] >= k && nodePs[i] >= threshold)
			{
				afternum++;
			}
		}
		while (updated)
		{
			if (newUpdatedNum == afternum)
			{
				break;
			}
			newUpdatedNum = afternum;
			cout << "updated candidate num" << afternum << endl;
			//cout << "updatednum" << updatedNum << endl;
			updatedNum = 0;
			double sumResult = 0;
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (degrees[i] == 0)
				{
					continue;
				}
				double tempP = nodePs[i];
				sumResult = 0;
				//
				nodeChain* nodeE = nodeC[i].next;
				while (nodeE != NULL)
				{
					double tempPro = nodePs[nodeE->node];
					if (edges[nodeE->edgeNum].p < tempPro)
					{
						tempPro = edges[nodeE->edgeNum].p;
					}
					sumResult += tempPro;
					nodeE = nodeE->next;
				}
				nodePs[i] = tempP < (sumResult / k) ? tempP : sumResult / k;
				if (nodePs[i] != tempP)
				{
					updated = true;
					updatedNum++;
				}
			}
		}
		//clacNodeP(X,maxDegree);
	}
	//clac result edges
	afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (degrees[i] >= k && nodePs[i] >= threshold)
		{
			afternum++;
		}
		else //delete all the related edges
		{
			nodeChain* temp = nodeC[i].next;
			while (temp != NULL)
			{
				edgeState[temp->edgeNum] = 0;
				temp = temp->next;
			}
		}
	}
	int tempEdgeNum = edgeNum;
	edgeNum = 0;
	for (int i = 0; i < tempEdgeNum; i++)
	{
		if (edgeState[i] == 1)
		{
			edges[edgeNum].x = temp2Edges[i].x;
			edges[edgeNum].y = temp2Edges[i].y;
			edges[edgeNum].p = temp2Edges[i].p;
			edgeNum++;
		}
	}
	//cout << afternum << endl;
	delete[] nodePs;
	delete[] nodeC;
	delete[] X;
	delete[] tempEdge;
	return afternum;

}


int kddCoreDecompositionOriginSpeedUpMarkovInequality(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[])
{
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	//int edgeNum = inputEdgeNum;
	Edge* tempEdge = new Edge[maxDegree];
	nodeChain* nodeC = new nodeChain[NODE_COUNT + 1];
	for (int i = 0; i < edgeNum; i++)
	{
		nodeChain* temp0 = new nodeChain;
		nodeChain* temp1 = new nodeChain;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp0->node = edges[i].y;
		temp0->p = edges[i].p;
		temp0->edgeNum = i;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
		temp1->node = edges[i].x;
		temp1->p = edges[i].p;
		temp1->edgeNum = i;
	}
	double* X = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	while (edgeNum != newEdgeNum && edgeNum != 0)//there is no "edgeNum --", hence there while loop only run once.
	{
		//cout << edgeNum << endl;
		newEdgeNum = edgeNum;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] == 0)
			{
				nodePs[i] = 0;
				continue;
			}


			////
			nodeChain* tempNodeChain = nodeC[i].next;
			int edgeI = 0;
			while (tempNodeChain != NULL)
			{
				tempEdge[edgeI].x = i;
				tempEdge[edgeI].y = tempNodeChain->node;
				tempEdge[edgeI].p = tempNodeChain->p;
				edgeI++;
				tempNodeChain = tempNodeChain->next;
			}

			double temp = clacNodeP(i, degrees[i], tempEdge, maxDegree, degrees[i], k);
			nodePs[i] = temp;


		}
		//have calced all the nodePs
		bool updated = true;
		int updatedNum = 0;
		int newUpdatedNum = 0;
		afternum = 0;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] >= k && nodePs[i] >= threshold)
			{
				afternum++;
			}
		}
		while (updated)
		{
			if (newUpdatedNum == afternum)
			{
				break;
			}
			newUpdatedNum = afternum;
			cout << "updated candidate num" << afternum << endl;
			//cout << "updatednum" << updatedNum << endl;
			updatedNum = 0;
			double sumResult = 0;
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (degrees[i] == 0)
				{
					continue;
				}
				double tempP = nodePs[i];
				sumResult = 0;
				//
				nodeChain* nodeE = nodeC[i].next;
				while (nodeE != NULL)
				{
					double tempPro = nodePs[nodeE->node];
					if (edges[nodeE->edgeNum].p < tempPro)
					{
						tempPro = edges[nodeE->edgeNum].p;
					}
					sumResult += tempPro;
					//sumResult += nodePs[nodeE->node];
					nodeE = nodeE->next;
				}
				nodePs[i] = tempP < (sumResult / k) ? tempP : sumResult / k;
				if (nodePs[i] != tempP)
				{
					updated = true;
					updatedNum++;
				}
			}
		}
		//clacNodeP(X,maxDegree);
	}
	//clac result edges
	afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (degrees[i] >= k && nodePs[i] >= threshold)
		{
			afternum++;
		}
	}
	//cout << afternum << endl;

	nodeChain* freeNodeC = NULL;
	nodeChain* freeNodeC2 = NULL;
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		freeNodeC = nodeC[i].next;
		while (freeNodeC != NULL)
		{
			freeNodeC2 = freeNodeC->next;
			delete freeNodeC;
			freeNodeC = freeNodeC2;
		}
	}

	delete[] nodePs;
	delete[] nodeC;
	delete[] X;
	delete[] tempEdge;
	return afternum;

}


int kddCoreDecompositionOriginSpeedUpMarkovInequalityWithNodeStateRemoveEdges(int& edgeNum, orderEdge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[], int* nodeState)
{
	//init edgeindex for all edges
	for (int i = 0; i < edgeNum; i++)
	{
		edges[i].edgeIndex = i;
	}
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	//int edgeNum = inputEdgeNum;
	Edge* tempEdge = new Edge[maxDegree];
	orderEdge* temp2Edges = new orderEdge[edgeNum + 1];
	nodeChain* nodeC = new nodeChain[NODE_COUNT + 1];
	bool* edgeState = new bool[edgeNum + 1];
	for (int i = 0; i < edgeNum; i++)
	{
		edgeState[i] = true;
		temp2Edges[i].x = edges[i].x;
		temp2Edges[i].y = edges[i].y;
		temp2Edges[i].p = edges[i].p;
		temp2Edges[i].edgeIndex = edges[i].edgeIndex;
	}
	for (int i = 0; i < edgeNum; i++)
	{
		nodeChain* temp0 = new nodeChain;
		nodeChain* temp1 = new nodeChain;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp0->node = edges[i].y;
		temp0->p = edges[i].p;
		temp0->edgeNum = i;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
		temp1->node = edges[i].x;
		temp1->p = edges[i].p;
		temp1->edgeNum = i;
	}
	double* X = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	while (edgeNum != newEdgeNum && edgeNum != 0)//there is no "edgeNum --", hence there while loop only run once.
	{
		//cout << edgeNum << endl;
		newEdgeNum = edgeNum;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] == 0)
			{
				nodePs[i] = 0;
				continue;
			}


			////
			nodeChain* tempNodeChain = nodeC[i].next;
			int edgeI = 0;
			while (tempNodeChain != NULL)
			{
				tempEdge[edgeI].x = i;
				tempEdge[edgeI].y = tempNodeChain->node;
				tempEdge[edgeI].p = tempNodeChain->p;
				edgeI++;
				tempNodeChain = tempNodeChain->next;
			}

			double temp = clacNodeP(i, degrees[i], tempEdge, maxDegree, degrees[i], k);
			nodePs[i] = temp;
		}
		//have calced all the nodePs
		bool updated = true;
		int updatedNum = 0;
		int newUpdatedNum = 0;
		afternum = 0;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] >= k && nodePs[i] >= threshold)
			{
				afternum++;
			}
		}
		while (updated)
		{
			if (newUpdatedNum == afternum)
			{
				break;
			}
			newUpdatedNum = afternum;
			cout << "updated candidate num" << afternum << endl;
			//cout << "updatednum" << updatedNum << endl;
			updatedNum = 0;
			double sumResult = 0;
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (degrees[i] == 0)
				{
					continue;
				}
				double tempP = nodePs[i];
				sumResult = 0;
				//
				nodeChain* nodeE = nodeC[i].next;
				while (nodeE != NULL)
				{
					double tempPro = nodePs[nodeE->node];
					if (edges[nodeE->edgeNum].p < tempPro)
					{
						tempPro = edges[nodeE->edgeNum].p;
					}
					sumResult += tempPro;
					nodeE = nodeE->next;
				}
				nodePs[i] = tempP < (sumResult / k) ? tempP : sumResult / k;
				if (nodePs[i] != tempP)
				{
					updated = true;
					updatedNum++;
				}
			}
		}
		//clacNodeP(X,maxDegree);
	}
	//clac result edges
	afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{

		if (degrees[i] >= k && nodePs[i] >= threshold)
		{
			afternum++;
		}
		else //delete all the related edges
		{
			nodeChain* temp = nodeC[i].next;
			while (temp != NULL)
			{
				edgeState[temp->edgeNum] = false;
				temp = temp->next;
			}
		}
	}
	int tempEdgeNum = edgeNum;
	edgeNum = 0;
	for (int i = 0; i < tempEdgeNum; i++)
	{
		if (edgeState[i] == true)
		{
			edges[edgeNum].x = temp2Edges[i].x;
			edges[edgeNum].y = temp2Edges[i].y;
			edges[edgeNum].p = temp2Edges[i].p;
			edges[edgeNum].edgeIndex = temp2Edges[i].edgeIndex;
			edgeNum++;
		}
	}
	//clac result edges
	afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (nodeState[i] == PRUNED)
		{
			continue;
		}
		if (degrees[i] >= k && nodePs[i] >= threshold)
		{
			nodeState[i] = TOCONFIRM; //to be determined
			afternum++;
		}
		else
		{
			nodeState[i] = NOTINRESULT; // no exist
		}
	}
	//cout << afternum << endl;

	nodeChain* freeNodeC = NULL;
	nodeChain* freeNodeC2 = NULL;
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		freeNodeC = nodeC[i].next;
		while (freeNodeC != NULL)
		{
			freeNodeC2 = freeNodeC->next;
			delete freeNodeC;
			freeNodeC = freeNodeC2;
		}
	}

	delete[] nodePs;
	delete[] nodeC;
	delete[] X;
	delete[] tempEdge;
	return afternum;

}



int kddCoreDecompositionOriginSpeedUpMarkovInequalityWithNodeState(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[], int* nodeState)
{
	double* nodePs = new double[NODE_COUNT + 1];
	initDoubleArray(nodePs, NODE_COUNT + 1);
	int afternum = 0;
	//create a chain to speed up core decomposition
	//int edgeNum = inputEdgeNum;
	Edge* tempEdge = new Edge[maxDegree];
	nodeChain* nodeC = new nodeChain[NODE_COUNT + 1];
	for (int i = 0; i < edgeNum; i++)
	{
		nodeChain* temp0 = new nodeChain;
		nodeChain* temp1 = new nodeChain;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp0->node = edges[i].y;
		temp0->p = edges[i].p;
		temp0->edgeNum = i;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
		temp1->node = edges[i].x;
		temp1->p = edges[i].p;
		temp1->edgeNum = i;
	}
	double* X = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	while (edgeNum != newEdgeNum && edgeNum != 0)//there is no "edgeNum --", hence there while loop only run once.
	{
		//cout << edgeNum << endl;
		newEdgeNum = edgeNum;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] == 0)
			{
				nodePs[i] = 0;
				continue;
			}


			////
			nodeChain* tempNodeChain = nodeC[i].next;
			int edgeI = 0;
			while (tempNodeChain != NULL)
			{
				tempEdge[edgeI].x = i;
				tempEdge[edgeI].y = tempNodeChain->node;
				tempEdge[edgeI].p = tempNodeChain->p;
				edgeI++;
				tempNodeChain = tempNodeChain->next;
			}

			double temp = clacNodeP(i, degrees[i], tempEdge, maxDegree, degrees[i], k);
			nodePs[i] = temp;


		}
		//have calced all the nodePs
		bool updated = true;
		int updatedNum = 0;
		int newUpdatedNum = 0;
		afternum = 0;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] >= k && nodePs[i] >= threshold)
			{
				afternum++;
			}
		}
		while (updated)
		{
			if (newUpdatedNum == afternum)
			{
				break;
			}
			newUpdatedNum = afternum;
			cout << "updated candidate num" << afternum << endl;
			//cout << "updatednum" << updatedNum << endl;
			updatedNum = 0;
			double sumResult = 0;
			updated = false;
			for (int i = 0; i <= nodeNum; i++)
			{
				if (degrees[i] == 0)
				{
					continue;
				}
				double tempP = nodePs[i];
				sumResult = 0;
				//
				nodeChain* nodeE = nodeC[i].next;
				while (nodeE != NULL)
				{
					double tempPro = nodePs[nodeE->node];
					if (edges[nodeE->edgeNum].p < tempPro)
					{
						tempPro = edges[nodeE->edgeNum].p;
					}
					sumResult += tempPro;
					//sumResult += nodePs[nodeE->node];
					nodeE = nodeE->next;
				}
				nodePs[i] = tempP < (sumResult / k) ? tempP : sumResult / k;
				if (nodePs[i] != tempP)
				{
					updated = true;
					updatedNum++;
				}
			}

		}
		//clacNodeP(X,maxDegree);
	}
	//clac result edges
	afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (degrees[i] >= k && nodePs[i] >= threshold)
		{
			nodeState[i] = -1; //to be determined
			afternum++;
		}
		else
		{
			nodeState[i] = 0; // no exist
		}
	}
	//cout << afternum << endl;

	nodeChain* freeNodeC = NULL;
	nodeChain* freeNodeC2 = NULL;
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		freeNodeC = nodeC[i].next;
		while (freeNodeC != NULL)
		{
			freeNodeC2 = freeNodeC->next;
			delete freeNodeC;
			freeNodeC = freeNodeC2;
		}
	}

	delete[] nodePs;
	delete[] nodeC;
	delete[] X;
	delete[] tempEdge;
	return afternum;

}


void kddCoreDecompositionOriginSpeedUp(int& inputEdgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[])

{
	cout << "edgenum-- with multiple iterations" << endl;
	double* nodePs = new double[NODE_COUNT + 1];
	//create a chain to speed up core decomposition
	int edgeNum = inputEdgeNum;
	Edge* tempEdge = new Edge[maxDegree];
	nodeChain* nodeC = new nodeChain[NODE_COUNT + 1];
	for (int i = 0; i < edgeNum; i++)
	{
		nodeChain* temp0 = new nodeChain;
		nodeChain* temp1 = new nodeChain;
		temp0->next = nodeC[edges[i].x].next;
		nodeC[edges[i].x].next = temp0;
		temp0->node = edges[i].y;
		temp0->p = edges[i].p;
		temp0->edgeNum = i;
		temp1->next = nodeC[edges[i].y].next;
		nodeC[edges[i].y].next = temp1;
		temp1->node = edges[i].x;
		temp1->p = edges[i].p;
		temp1->edgeNum = i;
	}
	double* X = new double[NODE_COUNT*(maxDegree + 2)];
	int newEdgeNum = 0;
	maxDegree = findMAxDegree(edges, nodeNum, edgeNum, degrees);
	while (edgeNum != newEdgeNum && edgeNum != 0)
	{
		//cout << edgeNum << endl;
		newEdgeNum = edgeNum;
		for (int i = 0; i <= nodeNum; i++)
		{
			if (degrees[i] == 0)
			{
				continue;
			}


			////
			nodeChain* tempNodeChain = nodeC[i].next;
			int edgeI = 0;
			while (tempNodeChain != NULL)
			{
				tempEdge[edgeI].x = i;
				tempEdge[edgeI].y = tempNodeChain->node;
				tempEdge[edgeI].p = tempNodeChain->p;
				edgeI++;
				tempNodeChain = tempNodeChain->next;
			}

			double temp = clacNodeP(i, degrees[i], tempEdge, maxDegree, degrees[i], k);
			nodePs[i] = temp;
			if (temp < threshold && degrees[i] != 0)
			{
				//delete all the x
				degrees[i] = 0;
				nodeChain* tempNodeC = &nodeC[i];
				nodeChain* tempNodeNext = tempNodeC->next;
				while (tempNodeNext != NULL)
				{
					edgeNum--;
					degrees[tempNodeNext->node]--;
					//delete repeat edges
					nodeChain* tempNodeD = &nodeC[tempNodeNext->node];
					nodeChain* tempNodeDNext = tempNodeD->next;
					while (tempNodeDNext != NULL)
					{
						if (tempNodeDNext->node == i)
						{
							tempNodeD->next = tempNodeDNext->next;
							delete tempNodeDNext;
							break;
						}
						tempNodeD = tempNodeDNext;
						tempNodeDNext = tempNodeDNext->next;
					}

					tempNodeC = tempNodeNext;
					tempNodeNext = tempNodeNext->next;
					edges[tempNodeC->edgeNum].x = -1;
					edges[tempNodeC->edgeNum].y = -1;

					delete tempNodeC;
				}
				//delete tempNodeC;
				nodeC[i].next = NULL;
				/*for (int j = 0; j < edgeNum;)
				{
				if (edges[j].x == i || edges[j].y == i)
				{
				degrees[edges[j].x]--;
				degrees[edges[j].y]--;
				edges[j].x = edges[edgeNum - 1].x;
				edges[j].y = edges[edgeNum - 1].y;
				edges[j].p = edges[edgeNum - 1].p;
				edgeNum--;
				continue;
				}
				j++;
				}*/
			}
		}
		//clacNodeP(X,maxDegree);
	}
	//clac result edges
	int afternum = 0;
	for (int i = 0; i <= nodeNum; i++)
	{
		if (degrees[i] >= k && nodePs[i] >= threshold)
		{
			afternum++;
		}
	}
	cout << afternum << endl;
	//free nodeC
	nodeChain* freeNodeC = NULL;
	nodeChain* freeNodeC2 = NULL;
	for (int i = 0; i <= NODE_COUNT; i++)
	{
		freeNodeC = nodeC[i].next;
		while (freeNodeC != NULL)
		{
			freeNodeC2 = freeNodeC->next;
			delete freeNodeC;
			freeNodeC = freeNodeC2;
		}
	}

	delete[] nodePs;
	delete[] nodeC;
	delete[] X;
	delete[] tempEdge;
	return;

}


void loadExistData(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum)//load data with edge probabilities
{
	char buffer[256];
	ifstream inEdges(edgesFileName);
	nodeNum = 0;
	edgeNum = 0;
	if (!inEdges.is_open())
	{
		cout << "Error opening file";
		exit(1);
	}
	int x, y;
	double p;

	// open edges
	while (!inEdges.eof())
	{
		inEdges.getline(buffer, 100);
		if (extractExistEdges(buffer, x, y, p))
		{
			edges[edgeNum].x = x;
			edges[edgeNum].y = y;
			edges[edgeNum].p = p;
			if (p > 1.0000001 || p < 0)
			{
				cout << "p error ||" << p << endl;
			}
			nodeNum = (nodeNum >= x ? nodeNum : x);
			nodeNum = (nodeNum >= y ? nodeNum : y);
			//edges[x*NODE_COUNT + y] = 1;
			//	if (edgeNum <= 100)
			//	{
			//	cout << buffer << " || " << edges[edgeNum].x << ',' << edges[edgeNum].y << "p" << edges[edgeNum].p << endl;
			//	}
			edgeNum++;
		}
	}
	inEdges.close();
	return;
}

//load data without egdges probabilities, so their probabilities are random generated.
void loadData(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum)
{
	char buffer[256];
	char outFile[256] = "outputRandP.txt";
	ofstream outEdges(outFile, ios::out);
	ifstream inEdges(edgesFileName);
	//ifstream inNodes(nodesFileName);
	nodeNum = 0;
	edgeNum = 0;
	if (!inEdges.is_open())
	{
		cout << "Error opening file";
		exit(1);
	}
	int x, y;

	while (!inEdges.eof())
	{
		inEdges.getline(buffer, 100);
		extractEdges(buffer, x, y);
		edges[edgeNum].x = x;
		edges[edgeNum].y = y;
		edges[edgeNum].p = randP();
		outEdges << x << ',' << y << ',' << edges[edgeNum].p << endl;
		nodeNum = (nodeNum >= x ? nodeNum : x);
		nodeNum = (nodeNum >= y ? nodeNum : y);
		edgeNum++;
	}
	outEdges.close();
	inEdges.close();
	return;
}


//load data without egdges probabilities, so their probabilities are random generated.
void loadDataLeastP(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum, double leastP)
{
	char buffer[256];
	char outFile[256] = "outputRandP.txt";
	ofstream outEdges(outFile, ios::out);
	ifstream inEdges(edgesFileName);
	//ifstream inNodes(nodesFileName);
	nodeNum = 0;
	edgeNum = 0;
	if (!inEdges.is_open())
	{
		cout << "Error opening file";
		exit(1);
	}
	int x, y;

	while (!inEdges.eof())
	{
		inEdges.getline(buffer, 100);
		extractEdges(buffer, x, y);
		edges[edgeNum].x = x;
		edges[edgeNum].y = y;
		double tempP = randP();
		while (tempP < leastP)
		{
			tempP = randP();
		}
		edges[edgeNum].p = tempP;;
		outEdges << x << ',' << y << ',' << edges[edgeNum].p << endl;
		nodeNum = (nodeNum >= x ? nodeNum : x);
		nodeNum = (nodeNum >= y ? nodeNum : y);
		edgeNum++;
	}
	outEdges.close();
	inEdges.close();
	return;
}

void loadDataLeastPInOrderByXY(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum, double leastP)
{
	char buffer[256];
	char outFile[256] = "outputRandP.txt";
	ofstream outEdges(outFile, ios::out);
	ifstream inEdges(edgesFileName);
	//ifstream inNodes(nodesFileName);
	nodeNum = 0;
	edgeNum = 0;
	if (!inEdges.is_open())
	{
		cout << "Error opening file";
		exit(1);
	}
	int x, y;

	while (!inEdges.eof())
	{
		inEdges.getline(buffer, 100);
		extractEdges(buffer, x, y);
		edges[edgeNum].x = x;
		edges[edgeNum].y = y;
		if (x > y)
		{
			continue;
		}
		double tempP = randP();
		while (tempP < leastP)
		{
			tempP = randP();
		}
		edges[edgeNum].p = tempP;;
		outEdges << x << ',' << y << ',' << edges[edgeNum].p << endl;
		nodeNum = (nodeNum >= x ? nodeNum : x);
		nodeNum = (nodeNum >= y ? nodeNum : y);
		edgeNum++;
	}
	outEdges.close();
	inEdges.close();
	return;
}

void initArray(int* array, int length)
{
	for (int i = 0; i < length; i++)
	{
		array[i] = 0;
	}
}

template<typename T> void initArrayWithValue(T* array, int length, T value)
{
	for (int i = 0; i < length; i++)
	{
		array[i] = value;
	}
}

void initDoubleArray(double* array, int length)
{
	for (int i = 0; i < length; i++)
	{
		array[i] = 0;
	}
}


void initPariArray(Edge* array, int length)
{
	for (int i = 0; i < length; i++)
	{
		array[i].x = 0;
		array[i].y = 0;
		array[i].p = 0;
	}
}

void extractEdges(char str[], int &x, int &y)
{
	//char* end;
	char temp[256];
	int tempIndex = 0;
	int i = 0;
	for (i = 0; '0' <= str[i] && str[i] <= '9'; i++)
	{
		temp[tempIndex++] = str[i];
	}
	temp[tempIndex] = '\0';
	x = atoi(temp);
	tempIndex = 0;
	while (str[++i] != '\0')
	{
		temp[tempIndex++] = str[i];
	}
	temp[tempIndex] = '\0';
	y = atoi(temp);
	return;
}

bool extractExistEdges(char str[], int &x, int &y, double& p)
{
	//char* end;
	if (strlen(str) <= 0)
	{
		return false;
	}
	char temp[256];
	int tempIndex = 0;
	int i = 0;
	for (i = 0; '0' <= str[i] && str[i] <= '9'; i++)
	{
		temp[tempIndex++] = str[i];
	}
	temp[tempIndex] = '\0';
	x = atoi(temp);
	tempIndex = 0;
	while (str[++i] != ',')
	{
		temp[tempIndex++] = str[i];
	}
	temp[tempIndex] = '\0';
	y = atoi(temp);

	tempIndex = 0;
	while (str[++i] != '\0')
	{
		temp[tempIndex++] = str[i];
	}
	temp[tempIndex] = '\0';
	p = atof(temp);
	return true;
}

int findOutConnectedCompoent(int* components, int n, Edge* edges, int edgeNum, int* degrees, earlyStopChainHead* nodeC)
{
	earlyStopChain* tempChain;
	stack<int> mystack;
	initArray(components, n + 1);
	int no_of_components = 0;
	for (int i = 0; i <= n; i++)
	{

		if (components[i] > 0 || degrees[i] == 0)
		{
			continue;
		}
		no_of_components++;
		mystack.push(i);
		components[i] = no_of_components;
		while (mystack.empty() == false)
		{
			int v;
			v = mystack.top();
			mystack.pop();

			tempChain = nodeC[v].next;
			while (tempChain != NULL)
			{
				if (components[tempChain->node] > 0)
				{
					tempChain = tempChain->next;
					continue;
				}
				mystack.push(tempChain->node);
				components[tempChain->node] = no_of_components;
				v = tempChain->node;

				tempChain = tempChain->next;
			}
		}
	}
	return no_of_components;
}

int countComponents(int n, Edge* edges, int edgeNum, int* degrees) {
	int k = n;
	int res = n + 1;
	int* root = new int[n + 1];
	for (int i = 0; i <= n; ++i)
	{
		root[i] = i;
		if (degrees[i] == 0)
		{
			--res;
		}
	}
	for (int i = 0; i < edgeNum; i++) {
		int x = find(root, edges[i].x), y = find(root, edges[i].y);
		if (x != y) {
			--res;
			root[y] = x;
		}
	}
	int node = 0;
	for (int i = 0; i <= n; i++)
	{
		if (degrees[i] != 0 && root[i] == i)
		{
			node++;
		}
	}
	cout << node << "total comp" << endl;
	cout << res << endl;
	delete[] root;
	return res;
}
int find(int* root, int i) {
	while (root[i] != i) i = root[i];
	return i;
}

void outputNodes(char* fileName, int nodes[], int nodeNum)
{
	ofstream outFile(fileName, ios::out);
	for (int i = 0; i <= nodeNum; i++)
	{
		if (nodes[i] == 1)
		{
			outFile << i << endl;
		}
	}
	outFile.close();

}