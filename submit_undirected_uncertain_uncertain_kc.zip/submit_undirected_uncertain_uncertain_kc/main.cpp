#include "uncertainKCore.h"
#include <array>
#include <chrono>
#include <cmath>
#include <limits>
#include <unordered_map>
#include <vector>
#include <omp.h>
#include <map>
std::vector<double> getVector(std::map<size_t, double> objFuncSumExponentsMap) {
	std::vector<double> v;
	for (auto entry : objFuncSumExponentsMap) {
		v.push_back(entry.second);
	}
	return v;
}
double differenceBetweenKddAndNewModel = 1;

int main()
{
	//cout << int(9.9) << endl;

	//system("pause");
	/*
	//yelp
	//int nodeCount = 552340;
	//int edgeCount = 1781910;
	//email_eron
	//int nodeCount = 36699;
	//int edgeCount = 183832;
	//for facebook
	//int nodeCount = 4100;
	//int edgeCount = 88235;
	int *nodes = new int[nodeCount + 1];
	int nodeNum = 0;
	int edgeNum = 0;
	Edge *edges = new Edge[edgeCount + 1];
	loadDataLeastPInOrderByXY("yelp", nodes, edges, nodeNum, edgeNum,0.5);
	return 0;*/
	char dataset[20][256] = { "flickr","dblp","yelprandp","email_eronrandp","email_eronrandp0.5","amazonrandp","facebookrandp","facebookrandp0.5","biomine","livejournalrandp" };
	int datasetNum = 8;
	int task = 9;
	/*
	task 1 means compute difference between new model and kdd model
	*/
	string tempS;
	int k = 10;
	double threshold = 0.9;
	double epsilon = 0.1;
	double delta = 0.1;
	for (int i = 0; i < 1; i++)
	{
		for (threshold = 0.7; threshold <= 0.7; threshold += 0.2)
		{
			for (k = 15; k <= 20; k += 5)
			{
				char *fileName = getOutFileName(tempS, dataset[i], k, epsilon, delta, threshold, task, 'k');
				if (k == 2)
				{
					if (ifstream(fileName))
					{
						cout << "file already exists" << endl;
						break;
					}
				}
				chooseTask(dataset[i], k, epsilon, delta, threshold, task, 'k');
			}
		}
		for (k = 15; k <= 20; k += 5) {
			for (threshold = 0.9; threshold <= 0.9; threshold += 0.15)
			{
				char *fileName = getOutFileName(tempS, dataset[i], k, epsilon, delta, threshold, task, 't');
				if (threshold == 0.1)
				{
					if (ifstream(fileName))
					{
						cout << "file already exists" << endl;
						break;
					}
				}
				chooseTask(dataset[i], k, epsilon, delta, threshold, task, 't');
			}
		}
	}
	/*if (ifstream(fileName))
	{
	cout << "file already exists" << endl;
	continue;
	}*/

	system("pause");
	return 0;
}


