#pragma once
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <stack>
#include <vector>
#include <string>
#include <queue>
using namespace std;

//test
//#define NODE_COUNT 20
//#define EDGE_COUNT 300 

//flickr
//#define NODE_COUNT 241000
//#define EDGE_COUNT 301000 

//part_DBLP
//#define NODE_COUNT 700000
//#define EDGE_COUNT 611000 
//edges
//#define NODE_COUNT 241000
//#define EDGE_COUNT 341000

//edges_middle
//#define NODE_COUNT 10312
//#define EDGE_COUNT 97344 

//DBLP
//#define NODE_COUNT 684920
//#define EDGE_COUNT 2284995 
//BIOMINE
//#define NODE_COUNT 1008201
//#define EDGE_COUNT 18008202

//liveJournal
//#define NODE_COUNT 3997963
//#define EDGE_COUNT 34681190
//amazon
//#define NODE_COUNT 548552
//#define EDGE_COUNT 925873

//there are three states for nodes, confirmed, pruned and to be determined
#define CONFIRMED 1
#define PRUNED -2
#define TOCONFIRM -1
#define NOTINRESULT 0

#define E_EXIST 1
#define E_NOTEXIST 0
#define E_TOCOMFIRM -1
#define PRECISIOM 0.000000000001
#define EDGE_MATIX (NODE_COUNT+1)*(NODE_COUNT+1)

struct upLowNum
{
	int remainingEdges;
	int curEdges;
	int solidEdges;
};
struct earlyStopChain
{
	int node = -1;
	int edgeIndex = -1;
	earlyStopChain* next = NULL;
};

struct earlyStopChainHead
{
	int node = -1;
	int remainingEdges = -1;
	int curEdges = -1;
	earlyStopChain* next = NULL;
};

struct nodeChain
{
	int edgeNum = -1;
	int node = -1;
	double p = 0;
	nodeChain* next = NULL;
};

struct Edge
{
	int x;
	int y;
	double p;
};

struct orderEdge
{
	int x;
	int y;
	double p;
	int edgeIndex;
};
void newModelDecompositionEarlyStopWithoutEdgeOrderWithNodeState
(orderEdge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden, int* nodeState, short* allEdgeState, int* allNodeState, upLowNum* nodeUL, int totalEdgeNum);
int kddCoreDecompositionOriginSpeedUpMarkovInequalityWithNodeStateRemoveEdges(int& edgeNum, orderEdge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[], int* nodeState);
void addSampleResultsEdgeStateWithAllNodeState(orderEdge* cerEdges, int edgeState[], int cerEdgesNum, int nodeNum, double* sampleResult, int* allNodeState, int sampleTime);
void newModelDecompositionEarlyStopWithoutEdgeOrderStateTransfer
(orderEdge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden, int* nodeState, short* allEdgeState, int* allNodeState, upLowNum* nodeUL, double threshold, int* result);
void addSampleResultsEdgeState(orderEdge* cerEdges, int edgeState[], int cerEdgesNum, int nodeNum, double* sampleResult);
int findMAxDegree(orderEdge* edges, int nodeNum, int edgeNum, int* degrees);
void loadData(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum);
void extractEdges(char str[], int &x, int &y);
void initArray(int* array, int length);
template<typename T> void initArrayWithValue(T* array, int length, T value);
template<typename T> void copyArray(T* source, T*destination, int len);
void initPariArray(Edge* array, int length);
int findMAxDegree(Edge* edges, int nodeNum, int edgeNum, int* degrees);
double clacNodeP(int node, int nodeDegree, Edge* edges, int maxDegree, int edgeNum, int k);
void kddCoreDecomposition(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[]);
void addKddNodes(Edge* edges, int nodeNum, int edgeNum, int* kddNode);
void addNewModelNodes(int* newModelNodes, double threshold, double* sampleResult, int nodeNum);
void initDoubleArray(double* array, int length);
double checkResult(int* newModelNodes, int* kddNodes, int nodeNum);
void newModelDecomposition(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult);
void weighedCoreDecomposition(int& edgeNum, Edge* edges, double threshold, int nodeNum, int k, int* degrees);
void addWeighedNodes(Edge* edges, int nodeNum, int edgeNum, int* weighedNode);
double randP();
void loadExistData(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum);
bool extractExistEdges(char str[], int &x, int &y, double& p);
void sampleKdd(int edgeNum, Edge* edges, int maxDegree, int nodeNum, int k, int degrees[], int resultNode[]);
void kddCoreDecompositionExpected(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int degrees[], int result[]);
void newModelDecompositionExpected(Edge* edges, int nodeNum, int edgeNum, int resultNode[], int originMaxDegree, int thresholdK);
void kddCoreDecompositionExpectedOrigin(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int degrees[], int result[]);
void clacInitialPro(int node, int nodeDegree, Edge* edges, int maxDegree, int edgeNum, double* initialPro, int nodeNum);
void kddCoreDecompositionExpected(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int degrees[], int result[]);
void kddCoreDecompositionOrigin(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[]);
void kddCoreDecompositionOriginSpeedUp(int& inputEdgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[]);
int kddCoreDecompositionOriginSpeedUpMarkovInequality(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[]);
void addSampleResultsEdgeState(Edge* cerEdges, int edgeState[], int cerEdgesNum, int nodeNum, double* sampleResult);
void newModelDecompositionChain(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex);
void certainCoreDecomposition(Edge* edges, int nodeNum, int& edgeNum, int k, int* resortNode, int* kStartIndex);
void certainCoreDecompositionSpeedUp(Edge* edges, int nodeNum, int& edgeNum, int k, int* resortNode, int* kStartIndex, int* components, int& no_compoents);
void newModelDecompositionChainNoOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon);
int caclTotalNodeNum(int edgeNum, int nodeNum, Edge* edges);
int calcSampleTimes(double delta, double epsilon, int nodeNum);

void newModelDecompositionEarlyStop(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden);
void newModelDecompositionEarlyStopWithoutEdgeOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden);
void newModelDecompositionEarlyStopWithoutEdgeOrderExpectedValue(Edge* edges, int nodeNum, int edgeNum, int maxdegree, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden);

int kddCoreDecompositionOriginSpeedUpMarkovInequalityWithNodeState(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[], int* nodeState);
int kddCoreDecompositionOriginSpeedUpMarkovInequalityRemoveEdges(int& edgeNum, Edge* edges, int maxDegree, double threshold, int nodeNum, int k, int degrees[]);
int countComponents(int n, Edge* edges, int edgeNum, int* degrees);
int find(int* root, int i);
int findOutConnectedCompoent(int* components, int n, Edge* edges, int edgeNum, int* degrees, earlyStopChainHead* nodeC);
void outputNodes(char* fileName, int nodes[], int nodeNum);
bool configureDataset(char* dataset);
void chooseTask(char* dataset, int k, double epsilon, double delta, double threshold, int task, char changeKOrThreshold);
void task1(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task2(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task3(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task4(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task5(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task6(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task7(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task8(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
void task9(char* dataset, int k, double epsilon, double delta, double threshold, ofstream& outFile, char changeKOrThreshold);
char* getOutFileName(string& tempS, char* dataset, int k, double epsilon, double delta, double threshold, int task, char changeKOrThreshold);
void loadDataLeastP(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum, double leastP);
void loadDataLeastPInOrderByXY(char edgesFileName[], int* nodes, Edge* edges, int& nodeNum, int& edgeNum, double leastP);
void newModelDecompositionChainNoOrderWithCoreOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon);
void newModelDecompositionEarlyStopWithoutEdgeOrderWithoutCoreValue(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden);
void newModelDecompositionChainNoOrderClacNoden(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden);
void newModelDecompositionDoubleEarlyStopWithoutEdgeOrder(Edge* edges, int nodeNum, int edgeNum, int k, double* sampleResult, int* resortNode, int* kStartIndex, double delta, double epsilon, int noden, int no_components, int* components, int* nodeState, double threshold);

